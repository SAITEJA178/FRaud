export type RiskLevel = 'critical' | 'high' | 'medium' | 'low';
export type ThreatVector = 'Message' | 'Call' | 'Email' | 'ID';
export type TrustScore = 'verified' | 'high' | 'medium' | 'low' | 'suspicious';

export interface Threat {
  id: number;
  sourceId: string;
  vector: ThreatVector;
  riskLevel: RiskLevel;
  reports: number;
  activity: string;
  createdAt: string;
}

export interface Transaction {
  id: number;
  transactionId: string;
  amount: number;
  merchantName: string;
  merchantId: string;
  riskPercentage: number;
  status: string;
  createdAt: string;
}

export interface FraudCase {
  id: number;
  caseName: string;
  caseType: string;
  sector: string;
  location: string;
  activeCount: number;
  status: 'active' | 'blocked' | 'investigating';
}

export interface NetworkNode {
  id: number;
  nodeName: string;
  threatCount: number;
  latency: number;
  status: string;
}

export interface UPIDetails {
  upiId: string;
  phoneNumber: string;
  name: string;
  bankName: string;
  accountType: string;
  email: string;
  aadharVerified: boolean;
  aadharLast4: string;
  trustScore: TrustScore;
  trustPercentage: number;
  lastTransaction: string;
  totalTransactions: number;
  reportedCases: number;
  fraudRisk: RiskLevel;
  location: string;
  sector: string;
  registeredDate: string;
  financialDetails: {
    monthlyIncome: string;
    employment: string;
    accountAge: string;
  };
  additionalDetails: {
    age: number;
    gender: string;
    maritalStatus: string;
  };
}

const THREAT_VECTORS: ThreatVector[] = ['Message', 'Call', 'Email', 'ID'];
const RISK_LEVELS: RiskLevel[] = ['critical', 'high', 'medium', 'low'];
const MERCHANTS = [
  'UPI Gateway',
  'Razorpay Checkout',
  'Stripe Connect',
  'PayU',
  'Paytm',
];
const SECTORS = [
  'Delhi Sector',
  'Bangalore Sector',
  'Mumbai Sector',
  'Kolkata Sector',
  'Hyderabad Sector',
];
const LOCATIONS = [
  'Nellore',
  'Mumbai',
  'Delhi',
  'Bangalore',
  'Kolkata',
  'Hyderabad',
];
const FRAUD_TYPES = [
  'Vishing Campaign',
  'KYC Update Scam',
  'Phishing Attack',
  'SIM Swap',
  'Fake App Download',
];

export function generateMockThreats(count: number = 10): Threat[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    sourceId:
      THREAT_VECTORS[i % 4] === 'Message'
        ? `+91 ${Math.floor(Math.random() * 9000000000) + 1000000000}`
        : THREAT_VECTORS[i % 4] === 'Email'
          ? `${Math.random().toString(36).substring(7)}@spam.com`
          : `${Math.random().toString(36).substring(7)}.upi`,
    vector: THREAT_VECTORS[i % 4],
    riskLevel: RISK_LEVELS[Math.floor(Math.random() * 4)],
    reports: Math.floor(Math.random() * 2000) + 100,
    activity: `${Math.floor(Math.random() * 60)}m ago`,
    createdAt: new Date(Date.now() - Math.random() * 86400000).toISOString(),
  }));
}

export function generateMockTransactions(count: number = 5): Transaction[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    transactionId: `PAY-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
    amount: Math.floor(Math.random() * 500000) + 1000,
    merchantName: MERCHANTS[Math.floor(Math.random() * MERCHANTS.length)],
    merchantId: `MERCH-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
    riskPercentage: Math.floor(Math.random() * 100),
    status: Math.random() > 0.3 ? 'completed' : 'pending',
    createdAt: new Date(Date.now() - Math.random() * 86400000).toISOString(),
  }));
}

export function generateMockFraudCases(count: number = 5): FraudCase[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    caseName: FRAUD_TYPES[i % FRAUD_TYPES.length],
    caseType: FRAUD_TYPES[i % FRAUD_TYPES.length].toLowerCase().replace(/ /g, '_'),
    sector: SECTORS[i % SECTORS.length],
    location: LOCATIONS[i % LOCATIONS.length],
    activeCount: Math.floor(Math.random() * 10000) + 100,
    status: Math.random() > 0.4 ? 'active' : 'blocked',
  }));
}

export function generateMockNetworkNodes(): NetworkNode[] {
  const nodes: NetworkNode[] = [
    { id: 1, nodeName: 'UPI Gateway', threatCount: 45, latency: 12, status: 'active' },
    { id: 2, nodeName: 'Payment Processor', threatCount: 23, latency: 18, status: 'active' },
    { id: 3, nodeName: 'Fraud Engine', threatCount: 89, latency: 15, status: 'active' },
    { id: 4, nodeName: 'ID Validator', threatCount: 12, latency: 8, status: 'active' },
    { id: 5, nodeName: 'Merchant Hub', threatCount: 34, latency: 22, status: 'syncing' },
    { id: 6, nodeName: 'Regional Node 1', threatCount: 56, latency: 25, status: 'active' },
    { id: 7, nodeName: 'Regional Node 2', threatCount: 41, latency: 19, status: 'active' },
  ];
  return nodes;
}

export function generateSecurityScore(): { score: number; change: number } {
  return {
    score: Math.floor(Math.random() * 10) + 90,
    change: Math.random() > 0.5 ? Math.random() * 2 : -Math.random() * 1,
  };
}

export function generateGlobalStats() {
  return {
    totalScans: Math.floor(Math.random() * 2000) + 1000,
    threatsDetected: Math.floor(Math.random() * 600) + 300,
    identitiesBlocked24h: Math.floor(Math.random() * 5000) + 3000,
    activeNodes: 7,
    liveLinks: Math.floor(Math.random() * 20000) + 10000,
  };
}

export function generateThreatToBeat(): {
  title: string;
  details: string;
  sector: string;
  severity: RiskLevel;
  timestamp: string;
} {
  const threats = [
    {
      title: 'Critical bug in UPI gateway callback',
      details: 'Potential double-spend vulnerability in South Asia Sector',
      sector: 'South Asia',
      severity: 'critical' as RiskLevel,
    },
    {
      title: 'Unusual payment pattern detected',
      details: 'Multiple high-value transactions from new accounts',
      sector: 'East Asia',
      severity: 'high' as RiskLevel,
    },
    {
      title: 'Fraudulent merchant activity',
      details: 'Merchant using stolen identity documents',
      sector: 'Southeast Asia',
      severity: 'critical' as RiskLevel,
    },
  ];

  const threat = threats[Math.floor(Math.random() * threats.length)];
  return {
    ...threat,
    timestamp: new Date(Date.now() - Math.random() * 3600000).toISOString(),
  };
}

export function generateUPIDetails(phoneNumber: string): UPIDetails {
  const names = ['Sai Teja', 'Rajesh Kumar', 'Priya Sharma', 'Amit Patel', 'Anjali Singh'];
  const banks = ['State Bank of India', 'ICICI Bank', 'HDFC Bank', 'Axis Bank', 'Google Pay'];
  const trustScores: TrustScore[] = ['verified', 'high', 'medium', 'low', 'suspicious'];
  const riskLevels: RiskLevel[] = ['critical', 'high', 'medium', 'low'];
  const locations = ['Delhi', 'Mumbai', 'Bangalore', 'Hyderabad', 'Kolkata'];
  const sectors = ['Delhi Sector', 'Mumbai Sector', 'Bangalore Sector', 'Hyderabad Sector', 'Kolkata Sector'];
  
  const name = names[Math.floor(Math.random() * names.length)];
  const bankName = banks[Math.floor(Math.random() * banks.length)];
  const trustScore = trustScores[Math.floor(Math.random() * trustScores.length)];
  const fraudRisk = riskLevels[Math.floor(Math.random() * riskLevels.length)];
  const location = locations[Math.floor(Math.random() * locations.length)];
  const sector = sectors[Math.floor(Math.random() * sectors.length)];
  
  return {
    upiId: `${Math.floor(Math.random() * 10000000)}@ybl`,
    phoneNumber,
    name,
    bankName,
    accountType: 'Primary account for receiving money',
    email: `${name.toLowerCase().replace(/ /g, '')}@gmail.com`,
    aadharVerified: Math.random() > 0.3,
    aadharLast4: Math.floor(Math.random() * 10000).toString().padStart(4, '0'),
    trustScore,
    trustPercentage: trustScore === 'verified' ? 95 : trustScore === 'high' ? 80 : trustScore === 'medium' ? 60 : trustScore === 'low' ? 30 : 10,
    lastTransaction: new Date(Date.now() - Math.random() * 604800000).toLocaleString(),
    totalTransactions: Math.floor(Math.random() * 500) + 10,
    reportedCases: Math.floor(Math.random() * 20),
    fraudRisk,
    location,
    sector,
    registeredDate: new Date(Date.now() - Math.random() * 63072000000).toLocaleDateString(),
    financialDetails: {
      monthlyIncome: `₹${(Math.random() * 200000 + 30000).toFixed(0)}`,
      employment: ['Service', 'Business', 'Self-Employed', 'Student'][Math.floor(Math.random() * 4)],
      accountAge: `${Math.floor(Math.random() * 10) + 1} years`,
    },
    additionalDetails: {
      age: Math.floor(Math.random() * 50) + 18,
      gender: Math.random() > 0.5 ? 'Male' : 'Female',
      maritalStatus: ['Single', 'Married', 'Divorced'][Math.floor(Math.random() * 3)],
    },
  };
}
