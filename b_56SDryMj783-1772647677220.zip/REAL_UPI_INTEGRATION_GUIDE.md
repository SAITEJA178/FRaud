# Real UPI & Phone Verification Integration Guide

Your Payment Threat AI app is ready to integrate with real banking and verification services. This document provides step-by-step integration instructions.

## Architecture Overview

The app currently has:
- Mock data demonstrating what real data looks like
- API structure at `/api/upi-verify` ready for real service integration
- Frontend prepared to handle real verification responses
- Fallback to mock data if real APIs aren't configured

## Required Integrations for Real Functionality

### 1. NPCI UPI Verification (Required for UPI lookup)

**Service:** National Payments Corporation of India  
**Endpoint:** https://api.npci.org.in/upi-verify  
**Registration:** https://www.npci.org.in/

**Steps:**
1. Register as a merchant with NPCI
2. Apply for UPI API access
3. Obtain API credentials (Merchant ID, API Key, Secret)
4. Implement signature verification

**Implementation in code:**
```typescript
// app/api/upi-verify/route.ts - callNPCIService()
const NPCI_API_KEY = process.env.NPCI_API_KEY;
const NPCI_MERCHANT_ID = process.env.NPCI_MERCHANT_ID;

async function verifyWithNPCI(upiId: string) {
  const signature = generateSignature(upiId, NPCI_API_KEY);
  
  const response = await fetch('https://api.npci.org.in/upi-verify', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${NPCI_API_KEY}`,
      'X-Merchant-Id': NPCI_MERCHANT_ID,
      'X-Signature': signature
    },
    body: JSON.stringify({ upiId })
  });
  
  return response.json();
}
```

### 2. Banking APIs (For account holder details)

**Available Banks:**
- **ICICI Bank:** https://www.icicibank.com/api
- **HDFC Bank:** https://www.hdfcbank.com/api
- **SBI:** https://www.sbi.co.in/api
- **Axis Bank:** https://www.axisbank.com/api
- **Google Pay/PhonePe:** Contact their developer program

**Data Retrieved:**
- Account holder name
- Account number (masked)
- Account type (Savings/Current)
- KYC verification status
- Account creation date
- Monthly transaction volume

**Implementation:**
```typescript
async function fetchBankingData(upiId: string) {
  const bank = upiId.split('@')[1];
  const bankApiKey = process.env[`${bank.toUpperCase()}_API_KEY`];
  
  const response = await fetch(`https://api.${bank}.com/account-verify`, {
    headers: { 'Authorization': `Bearer ${bankApiKey}` },
    body: JSON.stringify({ upiId })
  });
  
  return response.json();
}
```

### 3. UIDAI Aadhar Verification (For Aadhar validation)

**Service:** Unique Identification Authority of India  
**License Required:** e-KYC License  
**Portal:** https://uidai.gov.in/en/ecosystem/authentication/api-integration.html

**Steps:**
1. Apply for e-KYC license at UIDAI
2. Get approval and obtain API credentials
3. Integrate with Aadhar API endpoints

**Data Retrieved:**
- Aadhar verified status
- Name (from Aadhar)
- Age
- Address
- Verification timestamp

**Implementation:**
```typescript
async function verifyAadhar(phoneNumber: string, aadharConsent: boolean) {
  const aadharApiKey = process.env.UIDAI_API_KEY;
  
  const response = await fetch('https://api.uidai.gov.in/ekyc/verify', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${aadharApiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      phoneNumber,
      consentGiven: aadharConsent,
      purpose: 'Fraud Detection'
    })
  });
  
  return response.json();
}
```

### 4. Phone Number Verification (Telecom APIs)

**Providers:**
- **Jio (RIL):** https://www.jio.com/api
- **Airtel:** https://www.airtel.in/api
- **Vodafone:** https://www.vodafone.co.in/api

**Data Retrieved:**
- Phone number validity
- Active/inactive status
- Circle/Region
- Customer type (Prepaid/Postpaid)
- Account activation date

**Implementation:**
```typescript
async function verifyPhoneNumber(phoneNumber: string) {
  const telecomApiKey = process.env.TELECOM_API_KEY;
  
  const response = await fetch('https://api.telecom-verify.in/validate', {
    headers: { 'Authorization': `Bearer ${telecomApiKey}` },
    body: JSON.stringify({ phoneNumber })
  });
  
  return response.json();
}
```

### 5. Fraud Detection Database

**Data Sources:**
- **RBI Fraud Monitoring:** Contact RBI at https://www.rbi.org.in/
- **Cyber Crime Portal:** https://cybercrime.gov.in/
- **Banking Security Forum (BSFI):** Private consortium of Indian banks
- **Police Case Database:** State cyber crime departments

**Data Retrieved:**
- Previous fraud reports
- Risk assessment
- Case status
- Police case numbers
- Reported loss amount

**Implementation:**
```typescript
async function checkFraudDatabase(upiId: string, phoneNumber: string) {
  const fraudDbKey = process.env.FRAUD_DB_API_KEY;
  
  const response = await fetch('https://api.fraud-check.gov.in/lookup', {
    headers: { 'Authorization': `Bearer ${fraudDbKey}` },
    body: JSON.stringify({
      upiId,
      phoneNumber,
      checkType: 'comprehensive'
    })
  });
  
  return response.json();
}
```

## Environment Variables Setup

Add these to your `.env.local` file:

```bash
# NPCI UPI Service
NPCI_API_KEY=your_npci_api_key
NPCI_MERCHANT_ID=your_merchant_id
NPCI_SECRET=your_npci_secret

# Banking APIs
ICICI_API_KEY=your_icici_key
HDFC_API_KEY=your_hdfc_key
SBI_API_KEY=your_sbi_key
AXIS_API_KEY=your_axis_key

# UIDAI (Aadhar)
UIDAI_API_KEY=your_uidai_key
UIDAI_LICENSE_ID=your_license_id

# Telecom Verification
TELECOM_API_KEY=your_telecom_key

# Fraud Detection
FRAUD_DB_API_KEY=your_fraud_db_key
```

## Step-by-Step Integration Process

### Phase 1: Setup (Week 1)
1. Register with NPCI for UPI API access
2. Apply for UIDAI e-KYC license
3. Get API credentials from banks
4. Setup Telecom API access

### Phase 2: Implementation (Week 2-3)
1. Update `app/api/upi-verify/route.ts` with real API calls
2. Add error handling and timeout logic
3. Implement signature verification
4. Add retry logic for failed requests

### Phase 3: Testing (Week 4)
1. Test with NPCI sandbox environment
2. Test phone verification
3. Test Aadhar verification
4. Test fraud database lookup
5. Load testing and performance optimization

### Phase 4: Deployment (Week 5)
1. Deploy to production with real API keys
2. Monitor error rates and failures
3. Setup alerts for verification failures
4. Gradual rollout (10% → 50% → 100%)

## API Response Format Example

When fully integrated, the `/api/upi-verify` will return:

```json
{
  "success": true,
  "upiId": "9515543319@ybl",
  "phoneNumber": "+919515543319",
  "personalDetails": {
    "name": "Sai Teja",
    "bankName": "State Bank of India",
    "accountType": "Savings Account",
    "accountNumber": "****1234",
    "email": "saiteja@gmail.com",
    "registeredDate": "2020-03-15"
  },
  "aadharVerification": {
    "verified": true,
    "aadharLast4": "5432",
    "name": "Sai Teja",
    "age": 32,
    "address": "Delhi, India"
  },
  "phoneVerification": {
    "valid": true,
    "provider": "Jio",
    "active": true,
    "circle": "Delhi"
  },
  "fraudStatus": {
    "reports": 0,
    "riskLevel": "low",
    "casesReported": 0
  },
  "trustScore": "verified",
  "trustPercentage": 95
}
```

## Current Mock Data vs Real Data

**Currently (Mock):**
- Random data generation
- No actual verification
- Instant response (1.2s simulated delay)
- No real fraud detection

**After Integration (Real):**
- Actual account verification
- Real Aadhar/KYC matching
- API response times (2-5 seconds)
- Real fraud case lookup
- Actual trust scoring based on verification

## Compliance & Legal Notes

1. **Data Privacy:** Ensure compliance with RBI guidelines for handling customer data
2. **PII Protection:** All personal data must be encrypted and securely stored
3. **GDPR:** If processing EU customer data, ensure GDPR compliance
4. **KYC/AML:** Follow KYC and AML regulations for financial services
5. **API Agreements:** Read and comply with each service's terms of use

## Support & Resources

- **NPCI:** https://www.npci.org.in/
- **RBI:** https://www.rbi.org.in/
- **UIDAI:** https://uidai.gov.in/
- **Banking Regulation Act:** https://www.rbi.org.in/Scripts/NotificationUser.aspx
- **Payment Systems:** https://www.rbi.org.in/Scripts/BS_ViewMasDirectives.aspx

## Next Steps

1. Review this guide with your team
2. Contact NPCI for API access (2-4 weeks approval time)
3. Start sandbox testing
4. Plan rollout timeline
5. Setup monitoring and alerts

---

**Important:** Real UPI verification requires valid business registration and compliance with RBI/UIDAI regulations. This guide provides the technical integration path. Please consult with your compliance and legal teams before implementation.
