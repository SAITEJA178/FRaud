'use client';

import { useState } from 'react';
import { AlertTriangle, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface ScanResult {
  scannedValue: string;
  dataType: string;
  riskDetected: boolean;
  threatSeverity?: 'critical' | 'high' | 'medium' | 'low';
  details?: string;
  timestamp: string;
}

export function QRScanner() {
  const [manualInput, setManualInput] = useState('');
  const [scanResults, setScanResults] = useState<ScanResult[]>([]);

  const handleScan = async (scannedText: string) => {
    if (!scannedText.trim()) return;
    
    // Validate the scanned value
    const dataType = detectDataType(scannedText);

    // Simulate threat detection with mock data
    const riskDetected = Math.random() > 0.6;
    const severity = riskDetected
      ? (['critical', 'high', 'medium'] as const)[Math.floor(Math.random() * 3)]
      : 'low';

    const result: ScanResult = {
      scannedValue: scannedText,
      dataType,
      riskDetected,
      threatSeverity: severity,
      details: riskDetected 
        ? `Matched against ${Math.floor(Math.random() * 500) + 1} known threats` 
        : 'No threats detected',
      timestamp: new Date().toLocaleTimeString(),
    };

    setScanResults((prev) => [result, ...prev]);
  };

  const handleManualScan = () => {
    if (manualInput.trim()) {
      handleScan(manualInput);
      setManualInput('');
    }
  };

  const getRiskColor = (risk: boolean, severity?: string) => {
    if (!risk) return 'bg-emerald-950/40 border-emerald-900/30 text-emerald-100';
    switch (severity) {
      case 'critical':
        return 'bg-red-950/40 border-red-900/30 text-red-100';
      case 'high':
        return 'bg-orange-950/40 border-orange-900/30 text-orange-100';
      case 'medium':
        return 'bg-yellow-950/40 border-yellow-900/30 text-yellow-100';
      default:
        return 'bg-blue-950/40 border-blue-900/30 text-blue-100';
    }
  };

  const getRiskBadgeColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-900/50 text-red-200 border-red-700/50';
      case 'high':
        return 'bg-orange-900/50 text-orange-200 border-orange-700/50';
      case 'medium':
        return 'bg-yellow-900/50 text-yellow-200 border-yellow-700/50';
      case 'low':
        return 'bg-emerald-900/50 text-emerald-200 border-emerald-700/50';
      default:
        return 'bg-slate-900/50 text-slate-200 border-slate-700/50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Manual Input */}
      <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50 space-y-4">
        <h3 className="text-sm font-semibold text-gray-300">Manual Input</h3>

        <div className="space-y-2">
          <input
            type="text"
            value={manualInput}
            onChange={(e) => setManualInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleManualScan()}
            placeholder="Paste UPI ID, Phone, Email, or URL..."
            className="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500"
          />
          <Button
            onClick={handleManualScan}
            disabled={!manualInput.trim()}
            className="w-full bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold"
          >
            Scan Value
          </Button>
        </div>
      </div>

      {/* Scan Results */}
      {scanResults.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-gray-300">Scan History</h3>

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {scanResults.map((result, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-lg border ${getRiskColor(result.riskDetected, result.threatSeverity)}`}
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    {result.riskDetected ? (
                      <AlertTriangle className="w-5 h-5 flex-shrink-0" />
                    ) : (
                      <Check className="w-5 h-5 flex-shrink-0" />
                    )}
                    <div>
                      <p className="font-medium text-sm">
                        {result.riskDetected ? 'Threat Detected' : 'Safe to Use'}
                      </p>
                      <p className="text-xs opacity-75">{result.timestamp}</p>
                    </div>
                  </div>
                  {result.riskDetected && (
                    <Badge className={`${getRiskBadgeColor(result.threatSeverity || 'low')} text-xs`}>
                      {result.threatSeverity?.toUpperCase()}
                    </Badge>
                  )}
                </div>

                <div className="space-y-1">
                  <p className="text-xs font-mono break-all">{result.scannedValue}</p>
                  <p className="text-xs opacity-75">{result.details}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function detectDataType(
  value: string
): 'upi' | 'url' | 'phone' | 'email' {
  if (value.includes('@') && value.includes('.')) {
    if (value.includes('http')) return 'url';
    return 'email';
  }
  if (value.includes('@')) return 'upi';
  if (value.match(/^\+?[\d\s-()]+$/)) return 'phone';
  if (value.includes('http') || value.includes('www')) return 'url';
  return 'upi';
}
