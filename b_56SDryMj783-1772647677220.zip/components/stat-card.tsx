'use client';

import { ReactNode } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface StatCardProps {
  icon?: ReactNode;
  label: string;
  value: string | number;
  unit?: string;
  trend?: number;
  isPositive?: boolean;
  className?: string;
  variant?: 'default' | 'danger' | 'success' | 'warning';
}

export function StatCard({
  icon,
  label,
  value,
  unit,
  trend,
  isPositive = true,
  className = '',
  variant = 'default',
}: StatCardProps) {
  const bgClasses = {
    default: 'bg-slate-900/50 border-slate-700/50',
    danger: 'bg-red-950/40 border-red-900/30',
    success: 'bg-emerald-950/40 border-emerald-900/30',
    warning: 'bg-yellow-950/40 border-yellow-900/30',
  };

  const labelClasses = {
    default: 'text-gray-400',
    danger: 'text-red-300',
    success: 'text-emerald-300',
    warning: 'text-yellow-300',
  };

  const valueClasses = {
    default: 'text-white',
    danger: 'text-red-100',
    success: 'text-emerald-100',
    warning: 'text-yellow-100',
  };

  return (
    <div className={`p-4 rounded-lg border ${bgClasses[variant]} ${className}`}>
      <div className="flex items-start justify-between mb-3">
        <div>
          <p className={`text-sm font-medium ${labelClasses[variant]}`}>{label}</p>
        </div>
        {icon && <div className="text-gray-500">{icon}</div>}
      </div>
      <div className="flex items-baseline gap-2">
        <span className={`text-2xl font-bold ${valueClasses[variant]}`}>{value}</span>
        {unit && <span className="text-xs text-gray-500">{unit}</span>}
      </div>
      {trend !== undefined && (
        <div className="flex items-center gap-1 mt-2 text-xs">
          {isPositive ? (
            <TrendingUp className="w-3 h-3 text-red-400" />
          ) : (
            <TrendingDown className="w-3 h-3 text-emerald-400" />
          )}
          <span className={isPositive ? 'text-red-400' : 'text-emerald-400'}>
            {Math.abs(trend).toFixed(2)}%
          </span>
        </div>
      )}
    </div>
  );
}
