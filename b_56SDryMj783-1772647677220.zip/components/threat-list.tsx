'use client';

import { Threat } from '@/lib/mock-data';
import { Badge } from '@/components/ui/badge';
import { Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ThreatListProps {
  threats: Threat[];
  onClearLogs?: () => void;
  showActions?: boolean;
}

export function ThreatList({ threats, onClearLogs, showActions = true }: ThreatListProps) {
  const getRiskColor = (level: string) => {
    switch (level) {
      case 'critical':
        return 'bg-red-900/50 text-red-200 border-red-700/50';
      case 'high':
        return 'bg-orange-900/50 text-orange-200 border-orange-700/50';
      case 'medium':
        return 'bg-cyan-900/50 text-cyan-200 border-cyan-700/50';
      case 'low':
        return 'bg-emerald-900/50 text-emerald-200 border-emerald-700/50';
      default:
        return 'bg-slate-900/50 text-slate-200 border-slate-700/50';
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-gray-300">THREAT BLACKLIST</h3>
        {showActions && onClearLogs && (
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-500 hover:text-red-400 gap-1"
            onClick={onClearLogs}
          >
            <Trash2 className="w-4 h-4" />
            CLEAR LOGS
          </Button>
        )}
      </div>

      {threats.length === 0 ? (
        <div className="text-center py-6 text-gray-500 text-sm">No threats detected</div>
      ) : (
        <div className="space-y-2">
          {threats.map((threat) => (
            <div
              key={threat.id}
              className="p-3 rounded-lg border border-slate-700/50 bg-slate-900/30 hover:bg-slate-900/50 transition-colors"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <code className="text-sm text-cyan-400 font-mono">{threat.sourceId}</code>
                    <Badge variant="outline" className="text-xs">
                      {threat.vector}
                    </Badge>
                    <Badge variant="outline" className={`text-xs ${getRiskColor(threat.riskLevel)}`}>
                      {threat.riskLevel.charAt(0).toUpperCase() + threat.riskLevel.slice(1)}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>{threat.reports} reports</span>
                    <span>{threat.activity}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
