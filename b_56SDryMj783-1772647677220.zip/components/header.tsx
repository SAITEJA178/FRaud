'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Shield, Zap, Search, AlertTriangle, FileText, Wand2, Bell, Circle, MapPin, BarChart3, Network } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Header() {
  const pathname = usePathname();

  const navItems = [
    { label: 'Dashboard', href: '/', icon: BarChart3 },
    { label: 'Live Map', href: '/live-map', icon: MapPin },
    { label: 'UPI Details', href: '/upi-details', icon: Search },
    { label: 'Topology', href: '/network-topology', icon: Network },
    { label: 'Spam Intel', href: '/spam-intel', icon: AlertTriangle },
    { label: 'Batch', href: '/batch', icon: FileText },
  ];

  return (
    <header className="border-b border-cyan-900/20 bg-slate-950 sticky top-0 z-50">
      <div className="px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center">
            <Shield className="w-5 h-5 text-slate-950 font-bold" />
          </div>
          <span className="text-white font-bold text-lg tracking-tight">PAYMENT THREAT AI</span>
        </Link>

        {/* Navigation */}
        <nav className="flex items-center gap-1 mx-8">
          {navItems.map(({ label, href, icon: Icon }) => {
            const isActive = pathname === href;
            return (
              <Link key={href} href={href}>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`gap-2 ${
                    isActive
                      ? 'bg-cyan-900/40 text-cyan-400'
                      : 'text-gray-400 hover:text-gray-300 hover:bg-slate-900'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </Button>
              </Link>
            );
          })}
        </nav>

        {/* Right side actions */}
        <div className="flex items-center gap-4 ml-auto">
          <div className="flex items-center gap-2 text-xs text-cyan-400 px-3 py-1 bg-cyan-900/20 rounded-full">
            <Circle className="w-2 h-2 fill-cyan-400" />
            SYSTEM ONLINE
          </div>
          <Button variant="ghost" size="icon" className="text-gray-400 hover:text-cyan-400 relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </Button>
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600"></div>
        </div>
      </div>
    </header>
  );
}
