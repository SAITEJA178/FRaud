'use client';

import { Transaction } from '@/lib/mock-data';
import { Badge } from '@/components/ui/badge';
import { Shield, AlertTriangle } from 'lucide-react';

interface TransactionCardProps {
  transaction: Transaction;
}

export function TransactionCard({ transaction }: TransactionCardProps) {
  const getRiskColor = (risk: number) => {
    if (risk >= 80) return 'text-red-400';
    if (risk >= 50) return 'text-orange-400';
    if (risk >= 25) return 'text-yellow-400';
    return 'text-emerald-400';
  };

  const getRiskBg = (risk: number) => {
    if (risk >= 80) return 'bg-red-950/40 border-red-900/30';
    if (risk >= 50) return 'bg-orange-950/40 border-orange-900/30';
    if (risk >= 25) return 'bg-yellow-950/40 border-yellow-900/30';
    return 'bg-emerald-950/40 border-emerald-900/30';
  };

  return (
    <div className={`p-4 rounded-lg border ${getRiskBg(transaction.riskPercentage)} space-y-3`}>
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-3 flex-1">
          <div className="p-2 rounded-lg bg-slate-900/50">
            {transaction.riskPercentage >= 50 ? (
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
            ) : (
              <Shield className="w-5 h-5 text-emerald-400" />
            )}
          </div>
          <div className="min-w-0">
            <p className="font-medium text-white truncate">{transaction.merchantName}</p>
            <p className="text-xs text-gray-500">{transaction.transactionId}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="font-bold text-white">₹{transaction.amount.toLocaleString()}</p>
          <p className={`text-sm font-semibold ${getRiskColor(transaction.riskPercentage)}`}>
            Risk: {transaction.riskPercentage}%
          </p>
        </div>
      </div>

      <div className="flex items-center justify-between pt-2 border-t border-slate-700/30">
        <span className="text-xs text-gray-500">
          {new Date(transaction.createdAt).toLocaleTimeString()}
        </span>
        <Badge
          variant="outline"
          className={`text-xs ${transaction.status === 'completed' ? 'bg-emerald-900/30 text-emerald-300 border-emerald-700/50' : 'bg-yellow-900/30 text-yellow-300 border-yellow-700/50'}`}
        >
          {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
        </Badge>
      </div>
    </div>
  );
}
