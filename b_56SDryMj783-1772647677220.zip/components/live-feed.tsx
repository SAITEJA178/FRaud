'use client';

import { useEffect, useState } from 'react';
import { Transaction } from '@/lib/mock-data';
import { generateMockTransactions } from '@/lib/mock-data';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle, Zap } from 'lucide-react';

export function LiveFeed() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  useEffect(() => {
    // Initialize with mock data
    setTransactions(generateMockTransactions(5));

    // Simulate real-time updates
    const interval = setInterval(() => {
      setTransactions((prev) => {
        const newTx = generateMockTransactions(1)[0];
        return [newTx, ...prev.slice(0, 4)];
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const getRiskColor = (risk: number) => {
    if (risk >= 80) return 'text-red-400 bg-red-950/40 border-red-900/30';
    if (risk >= 50) return 'text-orange-400 bg-orange-950/40 border-orange-900/30';
    if (risk >= 25) return 'text-yellow-400 bg-yellow-950/40 border-yellow-900/30';
    return 'text-emerald-400 bg-emerald-950/40 border-emerald-900/30';
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-gray-300 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
          LIVE FEED
        </h3>
        <span className="text-xs text-red-400 font-semibold">● MONITORING</span>
      </div>

      <div className="space-y-2">
        {transactions.map((tx, idx) => (
          <div
            key={`${tx.id}-${idx}`}
            className={`p-3 rounded-lg border ${getRiskColor(tx.riskPercentage)} animate-in fade-in-50 slide-in-from-top-2 duration-500`}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  {tx.riskPercentage >= 50 ? (
                    <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  ) : (
                    <CheckCircle className="w-4 h-4 flex-shrink-0" />
                  )}
                  <p className="font-medium text-sm truncate">{tx.merchantName}</p>
                </div>
                <p className="text-xs text-gray-400">{tx.transactionId}</p>
              </div>

              <div className="text-right flex-shrink-0">
                <p className="font-bold text-sm">₹{(tx.amount / 1000).toFixed(0)}K</p>
                <p className="text-xs font-semibold">Risk: {tx.riskPercentage}%</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
