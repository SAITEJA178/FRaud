'use client';

import { useState, FormEvent } from 'react';
import { Search, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ThreatSearchProps {
  placeholder?: string;
  onSearch: (query: string) => void | Promise<void>;
  isLoading?: boolean;
  buttonText?: string;
}

export function ThreatSearch({
  placeholder = 'Enter UPI ID or Payment URL (e.g. rajesh@upi)...',
  onSearch,
  isLoading = false,
  buttonText = 'LOOKUP',
}: ThreatSearchProps) {
  const [query, setQuery] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      await onSearch(query);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-3 w-full">
      <div className="flex-1 relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-cyan-400" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={placeholder}
          className="w-full pl-12 pr-4 py-3 bg-slate-900 border border-cyan-900/40 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/20 transition-colors"
        />
      </div>
      <Button
        type="submit"
        disabled={isLoading}
        className="bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold px-8 min-w-fit"
      >
        {isLoading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin mr-2" />
            SEARCHING...
          </>
        ) : (
          buttonText
        )}
      </Button>
    </form>
  );
}
