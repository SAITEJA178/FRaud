'use client';

import { useState } from 'react';
import { Copy, Download, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import QRCode from 'qrcode.react';
import { useToast } from '@/hooks/use-toast';

interface QRGeneratorProps {
  initialValue?: string;
  dataType?: 'upi' | 'url' | 'phone' | 'email';
}

export function QRGenerator({ initialValue = '', dataType = 'upi' }: QRGeneratorProps) {
  const [value, setValue] = useState(initialValue);
  const [type, setType] = useState(dataType);
  const [qrValue, setQrValue] = useState('');
  const { toast } = useToast();

  const generateQR = async () => {
    if (!value.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter a value to generate QR code',
        variant: 'destructive',
      });
      return;
    }

    try {
      const response = await fetch('/api/qr-codes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value, type }),
      });

      const data = await response.json();
      if (data.success) {
        setQrValue(value);
        toast({
          title: 'Success',
          description: 'QR code generated successfully',
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to generate QR code',
        variant: 'destructive',
      });
    }
  };

  const downloadQR = () => {
    const qrElement = document.getElementById('qr-code');
    if (qrElement) {
      const canvas = qrElement.querySelector('canvas');
      if (canvas) {
        const url = canvas.toDataURL('image/png');
        const link = document.createElement('a');
        link.href = url;
        link.download = `qr-${type}-${Date.now()}.png`;
        link.click();
      }
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(value);
    toast({
      title: 'Copied',
      description: 'Value copied to clipboard',
    });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div>
          <label className="text-sm font-medium text-gray-300 block mb-2">Data Type</label>
          <select
            value={type}
            onChange={(e) => setType(e.target.value as any)}
            className="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-cyan-500 text-sm"
          >
            <option value="upi">UPI Address</option>
            <option value="url">Payment URL</option>
            <option value="phone">Phone Number</option>
            <option value="email">Email Address</option>
          </select>
        </div>

        <div>
          <label className="text-sm font-medium text-gray-300 block mb-2">Value</label>
          <input
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={
              type === 'upi'
                ? 'merchant@upi'
                : type === 'phone'
                  ? '+91 9876543210'
                  : type === 'email'
                    ? 'merchant@example.com'
                    : 'https://payment.example.com'
            }
            className="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <Button
          onClick={generateQR}
          className="w-full bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Generate QR Code
        </Button>
      </div>

      {qrValue && (
        <div className="space-y-4 p-6 rounded-lg bg-slate-900/50 border border-slate-700/50">
          <div className="flex justify-center p-4 bg-white rounded-lg">
            <div id="qr-code">
              <QRCode value={qrValue} size={256} level="H" includeMargin={true} />
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={downloadQR}
              variant="outline"
              className="flex-1 border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
            >
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
            <Button
              onClick={copyToClipboard}
              variant="outline"
              className="flex-1 border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy Value
            </Button>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-700/30">
            <p className="text-xs text-gray-500 mb-1">Encoded Value:</p>
            <p className="text-xs font-mono text-cyan-400 break-all">{qrValue}</p>
          </div>
        </div>
      )}
    </div>
  );
}
