'use client';

import { useEffect, useState } from 'react';
import { NetworkNode } from '@/lib/mock-data';
import { AlertTriangle, Lock, CheckCircle } from 'lucide-react';

interface NetworkTopologyProps {
  nodes: NetworkNode[];
}

export function NetworkTopology({ nodes }: NetworkTopologyProps) {
  const [svgSize] = useState({ width: 1000, height: 400 });

  // Calculate positions in a grid/network layout
  const getNodePosition = (index: number) => {
    const cols = 4;
    const row = Math.floor(index / cols);
    const col = index % cols;
    const x = 150 + col * 220;
    const y = 100 + row * 150;
    return { x, y };
  };

  // Generate random connections between nodes
  const generateConnections = () => {
    const connections = [];
    for (let i = 0; i < nodes.length - 1; i++) {
      if (Math.random() > 0.4) {
        connections.push({ from: i, to: i + 1 });
      }
    }
    return connections;
  };

  const connections = generateConnections();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return { fill: '#06B6D4', className: 'text-cyan-400' };
      case 'syncing':
        return { fill: '#F59E0B', className: 'text-amber-400' };
      case 'offline':
        return { fill: '#EF4444', className: 'text-red-400' };
      default:
        return { fill: '#10B981', className: 'text-emerald-400' };
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-semibold text-gray-300">NETWORK TOPOLOGY GRID</h3>

      <div className="bg-slate-900/30 border border-slate-700/50 rounded-lg p-4 overflow-x-auto">
        <svg viewBox={`0 0 ${svgSize.width} ${svgSize.height}`} className="min-w-full">
          {/* Draw connections */}
          {connections.map((conn, idx) => {
            const from = getNodePosition(conn.from);
            const to = getNodePosition(conn.to);
            return (
              <line
                key={`conn-${idx}`}
                x1={from.x}
                y1={from.y}
                x2={to.x}
                y2={to.y}
                stroke="#1F2937"
                strokeWidth="2"
                markerEnd="url(#arrowhead)"
              />
            );
          })}

          {/* Arrow marker */}
          <defs>
            <marker
              id="arrowhead"
              markerWidth="10"
              markerHeight="10"
              refX="9"
              refY="3"
              orient="auto"
            >
              <polygon points="0 0, 10 3, 0 6" fill="#4B5563" />
            </marker>
          </defs>

          {/* Draw nodes */}
          {nodes.map((node, idx) => {
            const pos = getNodePosition(idx);
            const statusColor = getStatusColor(node.status);

            return (
              <g key={`node-${idx}`}>
                {/* Node circle */}
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r="35"
                  fill="none"
                  stroke={statusColor.fill}
                  strokeWidth="2"
                  opacity="0.5"
                />

                {/* Node core */}
                <circle cx={pos.x} cy={pos.y} r="20" fill={statusColor.fill} opacity="0.3" />

                {/* Status indicator */}
                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r="8"
                  fill={statusColor.fill}
                  className="animate-pulse"
                />

                {/* Threat count label */}
                <text
                  x={pos.x}
                  y={pos.y + 55}
                  textAnchor="middle"
                  className="text-xs fill-gray-300"
                  fontSize="11"
                >
                  {node.nodeName}
                </text>

                <text
                  x={pos.x}
                  y={pos.y + 72}
                  textAnchor="middle"
                  className="text-xs fill-red-400 font-bold"
                  fontSize="10"
                >
                  {node.threatCount} threats
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Node status list */}
      <div className="grid grid-cols-2 gap-2 text-xs">
        {nodes.map((node) => {
          const statusColor = getStatusColor(node.status);
          const icons = {
            active: <CheckCircle className="w-3 h-3" />,
            syncing: <AlertTriangle className="w-3 h-3" />,
            offline: <Lock className="w-3 h-3" />,
          };

          return (
            <div key={node.id} className="flex items-center gap-2 p-2 rounded bg-slate-900/30 border border-slate-700/30">
              <div
                className="w-2 h-2 rounded-full"
                style={{ backgroundColor: statusColor.fill }}
              ></div>
              <span className="text-gray-400">{node.nodeName}</span>
              <span className={`ml-auto font-mono ${statusColor.className}`}>
                {node.latency}ms
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
