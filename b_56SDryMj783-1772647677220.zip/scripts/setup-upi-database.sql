-- Create UPI and Phone Database for Real Verification

CREATE TABLE IF NOT EXISTS upi_database (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  phone_number VARCHAR(20) NOT NULL UNIQUE,
  upi_id VARCHAR(100) NOT NULL UNIQUE,
  bank_name VARCHAR(255),
  account_type VARCHAR(255),
  email VARCHAR(255),
  aadhar_verified BOOLEAN DEFAULT FALSE,
  aadhar_last4 VARCHAR(4),
  age INTEGER,
  gender VARCHAR(20),
  location VARCHAR(255),
  sector VARCHAR(255),
  monthly_income VARCHAR(100),
  employment_type VARCHAR(100),
  account_age_years INTEGER,
  marital_status VARCHAR(50),
  registered_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_transaction TIMESTAMP,
  total_transactions INTEGER DEFAULT 0,
  reported_cases INTEGER DEFAULT 0,
  fraud_risk VARCHAR(20),
  trust_score VARCHAR(20),
  trust_percentage INTEGER,
  is_blacklisted BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Fraud Incidents Table for Map Visualization
CREATE TABLE IF NOT EXISTS fraud_incidents (
  id SERIAL PRIMARY KEY,
  upi_id VARCHAR(100) REFERENCES upi_database(upi_id),
  phone_number VARCHAR(20),
  incident_type VARCHAR(100),
  location_lat DECIMAL(10, 8),
  location_lng DECIMAL(11, 8),
  city VARCHAR(100),
  sector VARCHAR(100),
  amount_involved DECIMAL(15, 2),
  fraud_category VARCHAR(100),
  severity VARCHAR(20),
  status VARCHAR(50),
  reported_date TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample Real Data (Replace with actual data from your CSV/database)
INSERT INTO upi_database (name, phone_number, upi_id, bank_name, account_type, email, aadhar_verified, age, gender, location, sector, monthly_income, employment_type, account_age_years, marital_status) 
VALUES 
  ('K SAITEJA', '9515543319', '9515543319@ybl', 'State Bank of India', 'Primary account for receiving money', 'ksaiteja@gmail.com', TRUE, '20', 'Male', 'Nellore', 'Nellore Sector', '₹50000', 'Service', 2, 'Single'),
  ('AHAMED SHAIK', '9849571365', '9849571365@ybl', 'ICICI Bank', 'Savings Account', 'ahamedsh@gmail.com', TRUE, '21', 'Male', 'Nellore', 'Nellore Sector', '₹45000', 'Service', 1, 'Single'),
  ('BASKAR ADITHYA S', '9789923354', '9789923354@ybl', 'HDFC Bank', 'Current Account', 'baskar.a@gmail.com', FALSE, '21', 'Male', 'Chennai', 'Tamil Nadu Sector', '₹60000', 'Business', 3, 'Single'),
  ('MAQIL HUSAIN', '7358419172', '7358419172@ybl', 'Axis Bank', 'Savings Account', 'maqil.husain@gmail.com', TRUE, '23', 'Male', 'Chennai', 'Tamil Nadu Sector', '₹55000', 'Service', 2, 'Married');

-- Sample Fraud Incidents for Map
INSERT INTO fraud_incidents (upi_id, phone_number, incident_type, location_lat, location_lng, city, sector, amount_involved, fraud_category, severity, status)
VALUES 
  ('9515543319@ybl', '9515543319', 'Phishing', 14.4421, 79.9789, 'Nellore', 'Nellore Sector', 5000, 'Phishing Attack', 'high', 'reported'),
  ('9849571365@ybl', '9849571365', 'Unauthorized Transaction', 13.0872, 80.2707, 'Chennai', 'Tamil Nadu Sector', 15000, 'Unauthorized Access', 'critical', 'reported'),
  (NULL, '9876543210', 'UPI Fraud', 19.0760, 72.8777, 'Mumbai', 'Mumbai Sector', 25000, 'Fake Merchant', 'critical', 'reported'),
  (NULL, '9123456789', 'Identity Theft', 28.7041, 77.1025, 'New Delhi', 'Delhi Sector', 8000, 'Identity Theft', 'high', 'reported');

CREATE INDEX idx_upi_id ON upi_database(upi_id);
CREATE INDEX idx_phone_number ON upi_database(phone_number);
CREATE INDEX idx_fraud_incidents_location ON fraud_incidents(location_lat, location_lng);
CREATE INDEX idx_fraud_incidents_city ON fraud_incidents(city);
