-- Create threat_types enum
CREATE TYPE threat_type AS ENUM ('message', 'call', 'email', 'id', 'other');
CREATE TYPE risk_level AS ENUM ('critical', 'high', 'medium', 'low');
CREATE TYPE threat_status AS ENUM ('active', 'blocked', 'investigating');

-- Threats/Blacklist table
CREATE TABLE IF NOT EXISTS threats (
  id SERIAL PRIMARY KEY,
  source_id TEXT NOT NULL UNIQUE,
  threat_type threat_type NOT NULL,
  vector TEXT NOT NULL,
  risk_level risk_level NOT NULL,
  reports INTEGER DEFAULT 1,
  activity TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  status threat_status DEFAULT 'active'
);

-- Transactions/Payment data
CREATE TABLE IF NOT EXISTS transactions (
  id SERIAL PRIMARY KEY,
  transaction_id TEXT NOT NULL UNIQUE,
  amount DECIMAL(12, 2) NOT NULL,
  merchant_name TEXT NOT NULL,
  merchant_id TEXT NOT NULL,
  risk_percentage INTEGER DEFAULT 0,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- QR Scan logs
CREATE TABLE IF NOT EXISTS qr_scans (
  id SERIAL PRIMARY KEY,
  qr_code TEXT NOT NULL,
  data_type TEXT NOT NULL, -- 'upi', 'url', 'phone', 'email'
  scanned_value TEXT NOT NULL,
  risk_detected BOOLEAN DEFAULT FALSE,
  threat_id INTEGER REFERENCES threats(id),
  scan_timestamp TIMESTAMP DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Fraud cases/Global detection
CREATE TABLE IF NOT EXISTS fraud_cases (
  id SERIAL PRIMARY KEY,
  case_name TEXT NOT NULL,
  case_type TEXT NOT NULL, -- 'vishing', 'kyc_scam', 'phishing', etc
  sector TEXT NOT NULL,
  location TEXT NOT NULL,
  active_count INTEGER DEFAULT 0,
  status threat_status DEFAULT 'active',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Network nodes for topology
CREATE TABLE IF NOT EXISTS network_nodes (
  id SERIAL PRIMARY KEY,
  node_name TEXT NOT NULL,
  node_type TEXT NOT NULL, -- 'gateway', 'processor', 'merchant', 'user'
  status TEXT DEFAULT 'active',
  threat_count INTEGER DEFAULT 0,
  latency_ms INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for faster queries
CREATE INDEX IF NOT EXISTS idx_threats_source ON threats(source_id);
CREATE INDEX IF NOT EXISTS idx_threats_risk ON threats(risk_level);
CREATE INDEX IF NOT EXISTS idx_transactions_merchant ON transactions(merchant_id);
CREATE INDEX IF NOT EXISTS idx_qr_scans_value ON qr_scans(scanned_value);
CREATE INDEX IF NOT EXISTS idx_fraud_cases_status ON fraud_cases(status);

-- Enable realtime for tables
ALTER TABLE threats REPLICA IDENTITY FULL;
ALTER TABLE transactions REPLICA IDENTITY FULL;
ALTER TABLE qr_scans REPLICA IDENTITY FULL;
ALTER TABLE fraud_cases REPLICA IDENTITY FULL;
