import { NextResponse } from 'next/server';
import { generateMockFraudCases, generateThreatToBeat } from '@/lib/mock-data';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status');

    let fraudCases = generateMockFraudCases(limit);

    if (status) {
      fraudCases = fraudCases.filter((c) => c.status === status);
    }

    const threatToBeat = generateThreatToBeat();

    return NextResponse.json({
      success: true,
      data: {
        cases: fraudCases,
        threatToBeat: threatToBeat,
        total: fraudCases.length,
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch fraud cases' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    const newCase = {
      id: Math.floor(Math.random() * 100000),
      caseName: body.caseName || 'Unknown Fraud Case',
      caseType: body.caseType || 'phishing',
      sector: body.sector || 'Unknown',
      location: body.location || 'Unknown',
      activeCount: 0,
      status: 'investigating' as const,
    };

    return NextResponse.json({
      success: true,
      data: newCase,
      message: 'Fraud case reported successfully',
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to report fraud case' },
      { status: 400 }
    );
  }
}
