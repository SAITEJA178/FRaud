import { NextRequest, NextResponse } from 'next/server';

// Mock fraud incidents data for India map
const fraudIncidents = [
  {
    id: 1,
    city: 'Delhi',
    location: { lat: 28.7041, lng: 77.1025 },
    incidentType: 'Phishing Attack',
    amount: 5000,
    severity: 'high',
    count: 128432,
    date: '2026-03-04T10:30:00Z',
  },
  {
    id: 2,
    city: 'Mumbai',
    location: { lat: 19.0760, lng: 72.8777 },
    incidentType: 'Unauthorized Access',
    amount: 15000,
    severity: 'critical',
    count: 118720,
    date: '2026-03-04T09:15:00Z',
  },
  {
    id: 3,
    city: 'Bangalore',
    location: { lat: 12.9716, lng: 77.5946 },
    incidentType: 'Fake Merchant',
    amount: 12000,
    severity: 'high',
    count: 132413,
    date: '2026-03-04T08:45:00Z',
  },
  {
    id: 4,
    city: 'Chennai',
    location: { lat: 13.0827, lng: 80.2707 },
    incidentType: 'Identity Theft',
    amount: 8000,
    severity: 'critical',
    count: 95200,
    date: '2026-03-04T11:00:00Z',
  },
  {
    id: 5,
    city: 'Kolkata',
    location: { lat: 22.5726, lng: 88.3639 },
    incidentType: 'SIM Swap',
    amount: 6000,
    severity: 'high',
    count: 15187,
    date: '2026-03-04T07:30:00Z',
  },
  {
    id: 6,
    city: 'Hyderabad',
    location: { lat: 17.3850, lng: 78.4867 },
    incidentType: 'Vishing Attack',
    amount: 9500,
    severity: 'high',
    count: 136383,
    date: '2026-03-04T06:20:00Z',
  },
  {
    id: 7,
    city: 'Pune',
    location: { lat: 18.5204, lng: 73.8567 },
    incidentType: 'URL Spoofing',
    amount: 3000,
    severity: 'medium',
    count: 45000,
    date: '2026-03-04T12:10:00Z',
  },
  {
    id: 8,
    city: 'Jaipur',
    location: { lat: 26.9124, lng: 75.7873 },
    incidentType: 'Account Takeover',
    amount: 7500,
    severity: 'high',
    count: 32500,
    date: '2026-03-04T05:45:00Z',
  },
  {
    id: 9,
    city: 'Ahmedabad',
    location: { lat: 23.0225, lng: 72.5714 },
    incidentType: 'Malware Attack',
    amount: 11000,
    severity: 'critical',
    count: 28000,
    date: '2026-03-04T04:30:00Z',
  },
  {
    id: 10,
    city: 'Lucknow',
    location: { lat: 26.8467, lng: 80.9462 },
    incidentType: 'Credential Stuffing',
    amount: 4200,
    severity: 'medium',
    count: 18500,
    date: '2026-03-04T03:15:00Z',
  },
];

export async function GET(req: NextRequest) {
  const searchParams = req.nextUrl.searchParams;
  const city = searchParams.get('city');

  try {
    let incidents = fraudIncidents;

    if (city) {
      incidents = incidents.filter(
        (incident) => incident.city.toLowerCase() === city.toLowerCase()
      );
    }

    const totalFraudCases = incidents.reduce((sum, i) => sum + i.count, 0);
    const criticalCases = incidents.filter(
      (i) => i.severity === 'critical'
    ).length;

    return NextResponse.json({
      success: true,
      totalIncidents: incidents.length,
      totalFraudCases,
      criticalCases,
      accuracy: '99.8%',
      incidents,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('[v0] Fraud map error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch fraud incidents' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const { incident } = await req.json();

    // Validate incident data
    if (!incident.city || !incident.incidentType || !incident.severity) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // In production, save to database
    // For now, just return success
    return NextResponse.json({
      success: true,
      message: 'Fraud incident reported successfully',
      incidentId: Math.random().toString(36).substr(2, 9),
    });
  } catch (error) {
    console.error('[v0] Report incident error:', error);
    return NextResponse.json(
      { error: 'Failed to report incident' },
      { status: 500 }
    );
  }
}
