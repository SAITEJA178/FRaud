import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();

    const qrData = {
      id: Math.floor(Math.random() * 100000),
      value: body.value,
      type: body.type || 'upi', // 'upi', 'url', 'phone', 'email'
      qrCode: `QR-${Math.random().toString(36).substring(2, 11).toUpperCase()}`,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 3600000).toISOString(),
    };

    return NextResponse.json({
      success: true,
      data: qrData,
      message: 'QR code generated successfully',
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to generate QR code' },
      { status: 400 }
    );
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const qrCode = searchParams.get('code');

    if (!qrCode) {
      return NextResponse.json(
        { success: false, error: 'QR code parameter required' },
        { status: 400 }
      );
    }

    // In production, lookup in database
    const qrData = {
      id: Math.floor(Math.random() * 100000),
      qrCode: qrCode,
      value: `upi://pay?pa=merchant@upi&pn=MerchantName&am=10000`,
      type: 'upi',
      scans: Math.floor(Math.random() * 500),
      lastScan: new Date(Date.now() - Math.random() * 3600000).toISOString(),
      isValid: Math.random() > 0.2,
      createdAt: new Date(Date.now() - 86400000).toISOString(),
    };

    return NextResponse.json({
      success: true,
      data: qrData,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch QR code' },
      { status: 500 }
    );
  }
}
