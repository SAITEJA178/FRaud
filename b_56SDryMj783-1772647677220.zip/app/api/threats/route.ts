import { NextResponse } from 'next/server';
import { generateMockThreats, generateGlobalStats } from '@/lib/mock-data';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');
    const riskLevel = searchParams.get('riskLevel');

    let threats = generateMockThreats(limit);

    if (riskLevel) {
      threats = threats.filter((t) => t.riskLevel === riskLevel);
    }

    return NextResponse.json({
      success: true,
      data: threats,
      total: threats.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch threats' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    // In production, validate and store in database
    const newThreat = {
      id: Math.floor(Math.random() * 10000),
      sourceId: body.sourceId,
      vector: body.vector || 'Email',
      riskLevel: body.riskLevel || 'medium',
      reports: 1,
      activity: 'just now',
      createdAt: new Date().toISOString(),
    };

    return NextResponse.json({
      success: true,
      data: newThreat,
      message: 'Threat reported successfully',
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to report threat' },
      { status: 400 }
    );
  }
}
