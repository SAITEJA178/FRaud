import { NextResponse } from 'next/server';
import { generateMockTransactions } from '@/lib/mock-data';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '5');
    const merchantId = searchParams.get('merchantId');

    let transactions = generateMockTransactions(limit);

    if (merchantId) {
      transactions = transactions.filter((t) => t.merchantId === merchantId);
    }

    return NextResponse.json({
      success: true,
      data: transactions,
      total: transactions.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch transactions' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    const newTransaction = {
      id: Math.floor(Math.random() * 100000),
      transactionId: `PAY-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
      amount: body.amount || 10000,
      merchantName: body.merchantName || 'Unknown',
      merchantId: body.merchantId || 'MERCH-0000',
      riskPercentage: body.riskPercentage || 0,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    return NextResponse.json({
      success: true,
      data: newTransaction,
      message: 'Transaction created successfully',
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to create transaction' },
      { status: 400 }
    );
  }
}
