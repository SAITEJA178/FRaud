import { NextResponse } from 'next/server';
import {
  generateGlobalStats,
  generateSecurityScore,
  generateMockNetworkNodes,
} from '@/lib/mock-data';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');

    if (type === 'security-score') {
      return NextResponse.json({
        success: true,
        data: generateSecurityScore(),
        timestamp: new Date().toISOString(),
      });
    }

    if (type === 'network-nodes') {
      return NextResponse.json({
        success: true,
        data: generateMockNetworkNodes(),
        timestamp: new Date().toISOString(),
      });
    }

    // Default: return all analytics
    return NextResponse.json({
      success: true,
      data: {
        stats: generateGlobalStats(),
        securityScore: generateSecurityScore(),
        networkNodes: generateMockNetworkNodes(),
      },
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch analytics' },
      { status: 500 }
    );
  }
}
