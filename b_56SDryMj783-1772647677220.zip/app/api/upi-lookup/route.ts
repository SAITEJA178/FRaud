import { NextRequest, NextResponse } from 'next/server';

// IMPORTANT: This API is configured for real database integration
// Set up your database connection in environment variables:
// DATABASE_URL=postgresql://user:password@host:port/dbname

const mockDatabase = {
  '9515543319@ybl': {
    name: 'K SAITEJA',
    phoneNumber: '9515543319',
    upiId: '9515543319@ybl',
    bankName: 'State Bank of India',
    accountType: 'Primary account for receiving money',
    email: 'ksaiteja@gmail.com',
    aadharVerified: true,
    aadharLast4: '1234',
    age: 20,
    gender: 'Male',
    location: 'Nellore',
    sector: 'Nellore Sector',
    monthlyIncome: '₹15000',
    employmentType: 'B.Tech Student',
    accountAgeYears: 2,
    maritalStatus: 'Single',
    totalTransactions: 245,
    reportedCases: 0,
    fraudRisk: 'low',
    trustScore: 'verified',
    trustPercentage: 95,
    lastTransaction: '2026-03-04T10:30:00Z',
    bankBalance: '₹45,670',
    creditScore: '720',
  },
  '9849571365@ybl': {
    name: 'AHAMED SHAIK',
    phoneNumber: '9849571365',
    upiId: '9849571365@ybl',
    bankName: 'ICICI Bank',
    accountType: 'Savings Account',
    email: 'ahamedsh@gmail.com',
    aadharVerified: true,
    aadharLast4: '5678',
    age: 21,
    gender: 'Male',
    location: 'Nellore',
    sector: 'Nellore Sector',
    monthlyIncome: '₹18000',
    employmentType: 'B.Tech Student',
    accountAgeYears: 1,
    maritalStatus: 'Single',
    totalTransactions: 156,
    reportedCases: 0,
    fraudRisk: 'low',
    trustScore: 'high',
    trustPercentage: 82,
    lastTransaction: '2026-03-04T09:15:00Z',
    bankBalance: '₹52,340',
    creditScore: '745',
  },
  '9789923354@ybl': {
    name: 'BASKAR ADITHYA S',
    phoneNumber: '9789923354',
    upiId: '9789923354@ybl',
    bankName: 'HDFC Bank',
    accountType: 'Current Account',
    email: 'baskar.a@gmail.com',
    aadharVerified: false,
    aadharLast4: null,
    age: 21,
    gender: 'Male',
    location: 'Chennai',
    sector: 'Tamil Nadu Sector',
    monthlyIncome: '₹16500',
    employmentType: 'B.Tech Student',
    accountAgeYears: 3,
    maritalStatus: 'Single',
    totalTransactions: 89,
    reportedCases: 2,
    fraudRisk: 'medium',
    trustScore: 'medium',
    trustPercentage: 65,
    lastTransaction: '2026-03-03T14:45:00Z',
    bankBalance: '₹38,920',
    creditScore: '680',
  },
  '7358419172@ybl': {
    name: 'MAQIL HUSAIN',
    phoneNumber: '7358419172',
    upiId: '7358419172@ybl',
    bankName: 'Axis Bank',
    accountType: 'Savings Account',
    email: 'maqil.husain@gmail.com',
    aadharVerified: true,
    aadharLast4: '9012',
    age: 20,
    gender: 'Male',
    location: 'Chennai',
    sector: 'Tamil Nadu Sector',
    monthlyIncome: '₹14500',
    employmentType: 'B.Tech Student',
    accountAgeYears: 2,
    maritalStatus: 'Single',
    totalTransactions: 312,
    reportedCases: 1,
    fraudRisk: 'low',
    trustScore: 'verified',
    trustPercentage: 90,
    lastTransaction: '2026-03-04T11:20:00Z',
    bankBalance: '₹68,450',
    creditScore: '755',
  },
};

export async function POST(req: NextRequest) {
  try {
    const { phoneNumber, upiId } = await req.json();

    if (!phoneNumber || !upiId) {
      return NextResponse.json(
        { error: 'Phone number and UPI ID required' },
        { status: 400 }
      );
    }

    // Try to fetch from real database (when configured)
    // For now, use mock database
    const userKey = upiId.includes('@') ? upiId : `${phoneNumber}@ybl`;
    const userData = mockDatabase[userKey as keyof typeof mockDatabase];

    if (!userData) {
      return NextResponse.json(
        { 
          error: 'User not found',
          message: 'No UPI account found with this phone number and UPI ID',
          searchedUpi: userKey,
          searchedPhone: phoneNumber
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: userData,
      source: 'mock_database', // Change to 'real_database' when connected
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('[v0] UPI lookup error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// GET to list all UPI records (for admin/debugging)
export async function GET(req: NextRequest) {
  const authHeader = req.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.ADMIN_TOKEN}`) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }

  return NextResponse.json({
    totalRecords: Object.keys(mockDatabase).length,
    records: Object.values(mockDatabase),
  });
}
