'use client';

import { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, Server, Zap } from 'lucide-react';

const NETWORK_NODES = [
  { id: '1', name: 'UPI Gateway Core', type: 'server', x: 50, y: 15, status: 'active', issues: [] },
  { id: '2', name: 'Auth Server 1', type: 'server', x: 25, y: 35, status: 'active', issues: [] },
  { id: '3', name: 'Auth Server 2', type: 'server', x: 75, y: 35, status: 'warning', issues: ['High Latency'] },
  { id: '4', name: 'Database Primary', type: 'database', x: 20, y: 55, status: 'active', issues: [] },
  { id: '5', name: 'Database Replica', type: 'database', x: 80, y: 55, status: 'critical', issues: ['Sync Failed', 'Replication Lag'] },
  { id: '6', name: 'Cache Layer', type: 'cache', x: 50, y: 55, status: 'active', issues: [] },
  { id: '7', name: 'API Gateway 1', type: 'gateway', x: 15, y: 75, status: 'active', issues: [] },
  { id: '8', name: 'API Gateway 2', type: 'gateway', x: 50, y: 75, status: 'warning', issues: ['Rate Limit Exceeded'] },
  { id: '9', name: 'API Gateway 3', type: 'gateway', x: 85, y: 75, status: 'active', issues: [] },
  { id: '10', name: 'Payment Processor', type: 'service', x: 50, y: 35, status: 'critical', issues: ['Memory Usage 95%', 'CPU Spike'] },
];

const CONNECTIONS = [
  { from: '1', to: '2', status: 'healthy' },
  { from: '1', to: '3', status: 'warning' },
  { from: '1', to: '10', status: 'healthy' },
  { from: '2', to: '4', status: 'healthy' },
  { from: '3', to: '5', status: 'critical' },
  { from: '10', to: '6', status: 'healthy' },
  { from: '6', to: '7', status: 'healthy' },
  { from: '6', to: '8', status: 'warning' },
  { from: '6', to: '9', status: 'healthy' },
  { from: '4', to: '7', status: 'healthy' },
  { from: '5', to: '8', status: 'critical' },
];

const getNodeColor = (status) => {
  switch(status) {
    case 'active': return 'fill-green-500';
    case 'warning': return 'fill-yellow-500';
    case 'critical': return 'fill-red-500';
    default: return 'fill-slate-500';
  }
};

const getConnectionColor = (status) => {
  switch(status) {
    case 'healthy': return 'stroke-green-500';
    case 'warning': return 'stroke-yellow-500';
    case 'critical': return 'stroke-red-500';
    default: return 'stroke-slate-500';
  }
};

const getStatusBg = (status) => {
  switch(status) {
    case 'active': return 'bg-green-900/20 border-green-700/50 text-green-300';
    case 'warning': return 'bg-yellow-900/20 border-yellow-700/50 text-yellow-300';
    case 'critical': return 'bg-red-900/20 border-red-700/50 text-red-300';
    default: return 'bg-slate-900/20 border-slate-700/50 text-slate-300';
  }
};

export default function NetworkTopologyPage() {
  const [selectedNode, setSelectedNode] = useState(null);
  const [nodes, setNodes] = useState(NETWORK_NODES);
  const [systemHealth, setSystemHealth] = useState(72);

  useEffect(() => {
    const interval = setInterval(() => {
      setNodes(prev => 
        prev.map(node => {
          if (Math.random() > 0.95) {
            const newStatus = ['active', 'warning', 'critical'][Math.floor(Math.random() * 3)];
            return { ...node, status: newStatus };
          }
          return node;
        })
      );
      setSystemHealth(prev => {
        const change = (Math.random() - 0.5) * 5;
        return Math.min(100, Math.max(40, prev + change));
      });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const criticalCount = nodes.filter(n => n.status === 'critical').length;
  const warningCount = nodes.filter(n => n.status === 'warning').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Network Topology</h1>
          <p className="text-cyan-400">Real-time infrastructure monitoring and threat detection</p>
        </div>

        {/* Top Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
            <p className="text-xs text-slate-400 mb-2">SYSTEM HEALTH</p>
            <p className="text-3xl font-bold text-cyan-400">{systemHealth.toFixed(0)}%</p>
            <div className="mt-2 h-1 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-cyan-500" style={{width: `${systemHealth}%`}} />
            </div>
          </div>
          
          <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
            <p className="text-xs text-slate-400 mb-2">ACTIVE NODES</p>
            <p className="text-3xl font-bold text-green-400">{nodes.filter(n => n.status === 'active').length}/10</p>
          </div>

          <div className="bg-yellow-900/20 border border-yellow-700/50 rounded-lg p-4">
            <p className="text-xs text-yellow-400 mb-2">WARNINGS</p>
            <p className="text-3xl font-bold text-yellow-400">{warningCount}</p>
          </div>

          <div className="bg-red-900/20 border border-red-700/50 rounded-lg p-4">
            <p className="text-xs text-red-400 mb-2">CRITICAL</p>
            <p className="text-3xl font-bold text-red-400">{criticalCount}</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6">
          {/* Network Visualization */}
          <div className="col-span-2 bg-slate-900/40 border border-slate-800 rounded-lg p-6 overflow-auto">
            <svg viewBox="0 0 100 100" className="w-full h-auto bg-slate-900/20 rounded" preserveAspectRatio="xMidYMid meet">
              {/* Connections */}
              {CONNECTIONS.map((conn, idx) => {
                const fromNode = nodes.find(n => n.id === conn.from);
                const toNode = nodes.find(n => n.id === conn.to);
                return (
                  <line
                    key={`conn-${idx}`}
                    x1={fromNode?.x}
                    y1={fromNode?.y}
                    x2={toNode?.x}
                    y2={toNode?.y}
                    className={`${getConnectionColor(conn.status)} stroke-1 opacity-60`}
                    strokeDasharray={conn.status === 'critical' ? '2,2' : '0'}
                  />
                );
              })}

              {/* Nodes */}
              {nodes.map(node => (
                <g
                  key={node.id}
                  onClick={() => setSelectedNode(node)}
                  className="cursor-pointer"
                >
                  {/* Node circle */}
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r="3"
                    className={`${getNodeColor(node.status)} transition-all`}
                    opacity={selectedNode?.id === node.id ? 1 : 0.8}
                  />
                  
                  {/* Selection ring */}
                  {selectedNode?.id === node.id && (
                    <circle cx={node.x} cy={node.y} r="4.5" fill="none" stroke="currentColor" className="stroke-cyan-400" strokeWidth="0.5" />
                  )}

                  {/* Pulse effect for critical */}
                  {node.status === 'critical' && (
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r="3"
                      fill="none"
                      stroke="currentColor"
                      className="stroke-red-500 opacity-60"
                      strokeWidth="0.3"
                      style={{animation: 'pulse 2s infinite'}}
                    />
                  )}

                  {/* Node label */}
                  <text
                    x={node.x}
                    y={node.y + 6}
                    textAnchor="middle"
                    fontSize="1.5"
                    fill="#e2e8f0"
                    className="pointer-events-none"
                  >
                    {node.name.split(' ')[0]}
                  </text>
                </g>
              ))}
            </svg>
          </div>

          {/* Right Sidebar - Node Details */}
          <div className="space-y-4">
            {/* Selected Node Info */}
            {selectedNode && (
              <div className={`border rounded-lg p-4 ${getStatusBg(selectedNode.status)}`}>
                <p className="font-bold text-lg mb-2">{selectedNode.name}</p>
                <p className="text-xs opacity-75 mb-3">Type: {selectedNode.type.toUpperCase()}</p>
                
                {selectedNode.issues.length > 0 ? (
                  <div className="space-y-2">
                    <p className="text-xs font-semibold">Issues Detected:</p>
                    {selectedNode.issues.map((issue, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs">
                        <AlertTriangle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                        <span>{issue}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-xs">
                    <CheckCircle className="w-3 h-3" />
                    <span>All systems operational</span>
                  </div>
                )}
              </div>
            )}

            {/* Node Legend */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
              <p className="text-sm font-bold mb-3">Node Status</p>
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  <span>Active</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-yellow-500" />
                  <span>Warning</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-500" />
                  <span>Critical</span>
                </div>
              </div>
            </div>

            {/* All Nodes List */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
              <p className="text-sm font-bold mb-3">All Nodes</p>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {nodes.map(node => (
                  <div
                    key={node.id}
                    onClick={() => setSelectedNode(node)}
                    className={`p-2 rounded-lg cursor-pointer transition text-xs border ${
                      selectedNode?.id === node.id
                        ? 'bg-cyan-900/40 border-cyan-700'
                        : 'bg-slate-800/30 border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <div className={`w-1.5 h-1.5 rounded-full ${getNodeColor(node.status).replace('fill-', 'bg-')}`} />
                      <span className="font-semibold text-white">{node.name}</span>
                    </div>
                    {node.issues.length > 0 && (
                      <p className="text-red-300 text-xs ml-3.5">{node.issues.length} issue(s)</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes pulse {
          0%, 100% { r: 3; opacity: 0.8; }
          50% { r: 5; opacity: 0.2; }
        }
      `}</style>
    </div>
  );
}
