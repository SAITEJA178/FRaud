'use client';

import { useEffect, useState } from 'react';
import { AlertTriangle, Eye, Server, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function DashboardPage() {
  const [stats, setStats] = useState({ totalScans: 1730, threatsDetected: 514, identitiesBlocked24h: 4821, activeNodes: 127, liveLinks: 3456 });
  const [securityScore, setSecurityScore] = useState({ score: 98, change: 0.4 });
  const [threatAlert, setThreatAlert] = useState({ title: 'Critical bug in UPI gateway', details: 'Double-spend vulnerability detected', severity: 'critical' as const });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({ ...prev, totalScans: prev.totalScans + Math.floor(Math.random() * 10) }));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const getRiskColor = (severity: string) => {
    return severity === 'critical' ? 'bg-red-950/40 border-red-900/30 text-red-100' : 'bg-yellow-950/40 border-yellow-900/30 text-yellow-100';
  };

  return (
    <div className="bg-slate-950 text-white min-h-screen">
      {/* Top Alert Banner */}
      <div className={`border-b ${threatAlert.severity === 'critical' ? 'border-red-900/30' : 'border-yellow-900/30'}`}>
        <div className="max-w-7xl mx-auto px-6 py-3">
          <div className={`p-4 rounded-lg border ${getRiskColor(threatAlert.severity)} flex items-start justify-between gap-4`}>
            <div className="flex items-start gap-3 flex-1">
              <AlertTriangle className="w-5 h-5 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold text-sm mb-1">THREAT TO BEAT</p>
                <p className="text-sm mb-1">{threatAlert.title}</p>
                <p className="text-xs opacity-90">{threatAlert.details}</p>
              </div>
            </div>
            <Button variant="outline" size="sm" className="flex-shrink-0">
              View Details
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {[
            { label: 'TOTAL SCANS', value: stats.totalScans.toLocaleString(), icon: '👁️', color: 'text-cyan-400' },
            { label: 'THREATS', value: stats.threatsDetected, icon: '⚠️', color: 'text-red-400' },
            { label: 'BLOCKED (24H)', value: stats.identitiesBlocked24h.toLocaleString(), icon: '🚫', color: 'text-red-400' },
            { label: 'ACTIVE NODES', value: stats.activeNodes, icon: '🖥️', color: 'text-emerald-400' },
            { label: 'LIVE LINKS', value: stats.liveLinks.toLocaleString(), icon: '🔗', color: 'text-cyan-400' },
          ].map(({ label, value, icon, color }) => (
            <div key={label} className="p-4 rounded-lg bg-slate-900/50 border border-slate-700/50">
              <p className="text-xs font-medium text-gray-400 mb-2">{label}</p>
              <p className="text-2xl font-bold text-white">{value}</p>
            </div>
          ))}
        </div>

        {/* Security Score and System Status */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Security Score */}
          <div className="space-y-4">
            <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-sm font-medium text-gray-400 mb-1">SECURITY SCORE</p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold text-cyan-400">{securityScore.score}</span>
                    <span className="text-gray-400 text-sm">/100</span>
                  </div>
                </div>
              </div>

              <div className="w-full bg-slate-700/50 rounded-full h-2">
                <div className="bg-gradient-to-r from-cyan-400 to-cyan-500 h-2 rounded-full" style={{ width: `${securityScore.score}%` }}></div>
              </div>

              <div className="mt-4 flex items-center gap-2 text-xs">
                <TrendingUp className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">+0.4% change</span>
              </div>
            </div>

            {/* Threat Level */}
            <div className="p-6 rounded-lg bg-red-950/40 border border-red-900/30">
              <p className="text-xs font-medium text-red-300 mb-2 uppercase">THREAT LEVEL</p>
              <p className="text-3xl font-bold text-red-100 mb-2">HIGH</p>
              <div className="flex items-center gap-2 text-xs text-red-300">
                <AlertTriangle className="w-4 h-4" />
                Elevated threat activity detected
              </div>
            </div>

            {/* System Status */}
            <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50 space-y-3">
              <p className="text-xs font-semibold text-gray-300 uppercase">SYSTEM STATUS</p>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">API Latency</span>
                  <span className="font-mono text-xs text-cyan-400 font-semibold">12ms</span>
                </div>
                <div className="h-1 bg-slate-700/50 rounded-full overflow-hidden">
                  <div className="h-full w-1/3 bg-cyan-400 rounded-full"></div>
                </div>
              </div>
              <div className="space-y-2 pt-2 border-t border-slate-700/30">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Fraud Engine</span>
                  <span className="text-xs font-semibold text-emerald-400">Active</span>
                </div>
              </div>
            </div>
          </div>

          {/* Network Visualization Placeholder */}
          <div className="lg:col-span-2">
            <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50 space-y-4">
              <h3 className="text-sm font-semibold text-gray-300">LIVE NETWORK TOPOLOGY</h3>
              <div className="aspect-video bg-gradient-to-br from-slate-800 to-slate-900 rounded-lg border border-slate-700/50 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <p className="text-sm mb-2">Network visualization</p>
                  <p className="text-xs">Real-time node connections</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Live Feed Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-gray-300 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                  LIVE FEED
                </h3>
                <span className="text-xs text-red-400 font-semibold">● MONITORING</span>
              </div>
              <div className="space-y-2">
                {[
                  { name: 'UPI Gateway Node', amount: '₹102K', risk: '98%', icon: '🔴' },
                  { name: 'Razorpay Checkout', amount: '₹4.5K', risk: '12%', icon: '✅' },
                  { name: 'Stripe Connect', amount: '₹89K', risk: '45%', icon: '⚠️' },
                ].map((tx, idx) => (
                  <div key={idx} className="p-3 rounded-lg bg-slate-900/30 border border-slate-700/30 flex justify-between items-center">
                    <div className="flex-1">
                      <p className="font-medium text-sm">{tx.name}</p>
                      <p className="text-xs text-gray-400">{tx.amount}</p>
                    </div>
                    <span className="text-xs font-semibold text-red-400">Risk: {tx.risk}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Fraud Cases */}
          <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50 space-y-4">
            <h3 className="text-sm font-semibold text-gray-300">GLOBAL DETECTION</h3>
            <div className="space-y-2">
              {[
                { icon: '📞', title: 'Vishing Campaign', location: 'Nellore Sector', status: 'Active' },
                { icon: '🗂️', title: 'KYC Update Scam', location: 'Mumbai Sector', status: 'Blocked' },
              ].map((fraud, idx) => (
                <div key={idx} className="p-3 rounded-lg bg-slate-900/30 border border-slate-700/30">
                  <div className="flex items-start gap-2">
                    <span className="text-xl">{fraud.icon}</span>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-white">{fraud.title}</p>
                      <p className="text-xs text-gray-500">{fraud.location}</p>
                      <p className={`text-xs font-semibold mt-1 ${fraud.status === 'Active' ? 'text-red-400' : 'text-emerald-400'}`}>{fraud.status}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
