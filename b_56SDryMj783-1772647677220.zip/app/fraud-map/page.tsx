'use client';

import { useState, useEffect } from 'react';
import { AlertTriangle, MapPin, TrendingUp } from 'lucide-react';

const FRAUD_INCIDENTS = [
  { id: '1', city: 'Delhi', lat: 28.6139, lng: 77.2090, x: 55, y: 25, threatLevel: 'critical', incidentCount: 245, description: 'SIM Swap Fraud' },
  { id: '2', city: 'Mumbai', lat: 19.0760, lng: 72.8777, x: 25, y: 50, threatLevel: 'critical', incidentCount: 189, description: 'Phishing Campaign' },
  { id: '3', city: 'Bangalore', lat: 12.9716, lng: 77.5946, x: 60, y: 65, threatLevel: 'high', incidentCount: 156, description: 'UPI Malware' },
  { id: '4', city: 'Hyderabad', lat: 17.3850, lng: 78.4867, x: 58, y: 58, threatLevel: 'high', incidentCount: 142, description: 'OTP Theft' },
  { id: '5', city: 'Chennai', lat: 13.0827, lng: 80.2707, x: 65, y: 72, threatLevel: 'medium', incidentCount: 98, description: 'Account Takeover' },
  { id: '6', city: 'Kolkata', lat: 22.5726, lng: 88.3639, x: 75, y: 40, threatLevel: 'medium', incidentCount: 87, description: 'Fake UPI Apps' },
  { id: '7', city: 'Pune', lat: 18.5204, lng: 73.8567, x: 40, y: 55, threatLevel: 'medium', incidentCount: 76, description: 'Vishing Attacks' },
  { id: '8', city: 'Ahmedabad', lat: 23.0225, lng: 72.5714, x: 35, y: 48, threatLevel: 'low', incidentCount: 45, description: 'Fraud Alerts' },
  { id: '9', city: 'Jaipur', lat: 26.9124, lng: 75.7873, x: 48, y: 35, threatLevel: 'low', incidentCount: 32, description: 'Suspicious Activity' },
  { id: '10', city: 'Lucknow', lat: 26.8467, lng: 80.9462, x: 65, y: 30, threatLevel: 'low', incidentCount: 28, description: 'Reports Filed' },
];

const getThreatColor = (level) => {
  const colors = {
    critical: { bg: 'bg-red-600', text: 'text-red-400', bar: 'bg-red-500' },
    high: { bg: 'bg-orange-600', text: 'text-orange-400', bar: 'bg-orange-500' },
    medium: { bg: 'bg-yellow-600', text: 'text-yellow-400', bar: 'bg-yellow-500' },
    low: { bg: 'bg-green-600', text: 'text-green-400', bar: 'bg-green-500' },
  };
  return colors[level] || colors.low;
};

export default function FraudMapPage() {
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [liveIncidents, setLiveIncidents] = useState(FRAUD_INCIDENTS);
  const [accuracy, setAccuracy] = useState(99.8);

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveIncidents(prev => 
        prev.map(incident => ({
          ...incident,
          incidentCount: incident.incidentCount + Math.floor(Math.random() * 3)
        }))
      );
      setAccuracy(prev => {
        const newVal = prev + (Math.random() - 0.5) * 0.2;
        return Math.min(99.9, Math.max(99.5, newVal));
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const totalIncidents = liveIncidents.reduce((sum, i) => sum + i.incidentCount, 0);
  const criticalCount = liveIncidents.filter(i => i.threatLevel === 'critical').reduce((sum, i) => sum + i.incidentCount, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      <div className="flex h-screen overflow-hidden">
        {/* Left Sidebar */}
        <div className="w-80 bg-slate-950/50 border-r border-slate-800 p-6 overflow-y-auto space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="w-5 h-5 text-cyan-400" />
              <h1 className="text-2xl font-bold">Fraud Command</h1>
            </div>
            <p className="text-sm text-slate-400">Live Neural Stream</p>
          </div>

          {/* Stats */}
          <div className="space-y-4">
            <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
              <p className="text-xs text-slate-400 mb-2">TOTAL SCANS</p>
              <p className="text-3xl font-bold text-white">{totalIncidents.toLocaleString()}</p>
            </div>
            <div className="bg-red-900/20 border border-red-700/50 rounded-lg p-4">
              <p className="text-xs text-red-300 mb-2">THREATS</p>
              <p className="text-3xl font-bold text-red-400">{criticalCount}</p>
            </div>
          </div>

          {/* Real-time Intercepts */}
          <div>
            <h3 className="text-sm font-bold text-slate-300 mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              REAL-TIME INTERCEPTS
            </h3>
            <div className="space-y-3">
              {liveIncidents.slice(0, 5).map(incident => (
                <div
                  key={incident.id}
                  onClick={() => setSelectedIncident(incident)}
                  className={`p-3 rounded-lg border cursor-pointer transition ${
                    selectedIncident?.id === incident.id
                      ? 'bg-cyan-900/40 border-cyan-700'
                      : 'bg-slate-900/30 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <p className="font-semibold text-white text-sm">{incident.city} Sector</p>
                  <p className={`text-xs font-bold ${getThreatColor(incident.threatLevel).text}`}>
                    ₹{incident.incidentCount.toLocaleString()}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">{incident.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Query Section */}
          <div>
            <input
              type="text"
              placeholder="Query Sector (e.g. Nellore)..."
              className="w-full bg-slate-900/50 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-700"
            />
          </div>
        </div>

        {/* Main Map Area */}
        <div className="flex-1 relative bg-gradient-to-br from-blue-100 to-blue-50 overflow-hidden">
          {/* Map SVG */}
          <svg
            className="absolute inset-0 w-full h-full"
            viewBox="0 0 100 100"
            preserveAspectRatio="xMidYMid slice"
          >
            {/* India Map Background */}
            <defs>
              <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#e5e7eb" strokeWidth="0.1"/>
              </pattern>
            </defs>
            
            {/* Map Countries */}
            <g opacity="0.6">
              <path d="M 5 15 L 8 10 L 12 12 L 15 15 L 12 20 L 8 18 Z" fill="#fef3c7" stroke="#94a3b8" strokeWidth="0.3"/>
              <path d="M 30 5 L 35 8 L 38 15 L 35 20 L 30 18 Z" fill="#dbeafe" stroke="#94a3b8" strokeWidth="0.3"/>
              <path d="M 20 25 L 80 20 L 85 75 L 20 80 Z" fill="#dcfce7" stroke="#94a3b8" strokeWidth="0.3"/>
            </g>

            {/* Fraud Incident Markers */}
            {liveIncidents.map(incident => {
              const color = getThreatColor(incident.threatLevel).bg;
              const radius = incident.threatLevel === 'critical' ? 2 : incident.threatLevel === 'high' ? 1.5 : 1;
              
              return (
                <g key={incident.id}>
                  {/* Pulse rings */}
                  {incident.threatLevel === 'critical' && (
                    <>
                      <circle cx={incident.x} cy={incident.y} r={radius + 1.5} fill="none" stroke="currentColor" strokeWidth="0.3" className="opacity-30 animate-pulse" style={{animationDuration: '2s'}} />
                      <circle cx={incident.x} cy={incident.y} r={radius + 0.8} fill="none" stroke="currentColor" strokeWidth="0.3" className="opacity-50 animate-pulse" style={{animationDuration: '1.5s'}} />
                    </>
                  )}
                  
                  {/* Main marker */}
                  <circle cx={incident.x} cy={incident.y} r={radius} fill="currentColor" className={color} />
                  
                  {/* Selected indicator */}
                  {selectedIncident?.id === incident.id && (
                    <circle cx={incident.x} cy={incident.y} r={radius + 0.8} fill="none" stroke="#00d9ff" strokeWidth="0.5" />
                  )}
                </g>
              );
            })}

            {/* India Label */}
            <text x="45" y="95" fontSize="8" fontWeight="bold" fill="#64748b" opacity="0.4">INDIA</text>
          </svg>

          {/* Accuracy Badge */}
          <div className="absolute top-6 right-6 bg-slate-950/60 border border-slate-800 rounded-lg px-4 py-2 backdrop-blur">
            <p className="text-xs text-slate-400">DETECTION ACCURACY</p>
            <p className="text-2xl font-bold text-cyan-400">{accuracy.toFixed(1)}%</p>
          </div>

          {/* Selected Incident Details */}
          {selectedIncident && (
            <div className="absolute bottom-6 right-6 bg-slate-950/90 border border-cyan-700/50 rounded-lg p-4 w-64 backdrop-blur">
              <div className="mb-3">
                <p className="text-sm font-bold text-white">{selectedIncident.city} Sector</p>
                <p className={`text-xs font-semibold ${getThreatColor(selectedIncident.threatLevel).text}`}>
                  {selectedIncident.threatLevel.toUpperCase()}
                </p>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Incidents:</span>
                  <span className="text-white font-semibold">{selectedIncident.incidentCount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Threat Type:</span>
                  <span className="text-white font-semibold">{selectedIncident.description}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
