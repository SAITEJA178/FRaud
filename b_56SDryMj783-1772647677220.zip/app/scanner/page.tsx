'use client';

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { QRGenerator } from '@/components/qr-generator';
import { QRScanner } from '@/components/qr-scanner';
import { Zap } from 'lucide-react';

export default function ScannerPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        {/* Page Header */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Zap className="w-6 h-6 text-cyan-400" />
            <h1 className="text-3xl font-bold">Scanner</h1>
          </div>
          <p className="text-gray-400">Generate and scan QR codes for secure payment verification</p>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="scanner" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 bg-slate-900 border border-slate-700/50 p-1">
            <TabsTrigger
              value="scanner"
              className="data-[state=active]:bg-cyan-500 data-[state=active]:text-slate-950"
            >
              Scan QR Codes
            </TabsTrigger>
            <TabsTrigger
              value="generate"
              className="data-[state=active]:bg-cyan-500 data-[state=active]:text-slate-950"
            >
              Generate QR Codes
            </TabsTrigger>
          </TabsList>

          <TabsContent value="scanner" className="space-y-4">
            <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50">
              <h2 className="text-lg font-semibold mb-4">QR Code Scanner</h2>
              <p className="text-sm text-gray-400 mb-6">
                Scan QR codes or manually enter payment details to check for threats and verify
                legitimacy. Our system cross-references against a database of known fraud patterns.
              </p>
              <QRScanner />
            </div>
          </TabsContent>

          <TabsContent value="generate" className="space-y-4">
            <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50">
              <h2 className="text-lg font-semibold mb-4">QR Code Generator</h2>
              <p className="text-sm text-gray-400 mb-6">
                Generate secure QR codes for payment URLs, UPI addresses, phone numbers, and emails.
                Share these with customers and partners for easy payment processing.
              </p>
              <QRGenerator />
            </div>
          </TabsContent>
        </Tabs>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-lg bg-cyan-950/40 border border-cyan-900/30 space-y-2">
            <h3 className="font-semibold text-cyan-300 text-sm">Scanner Benefits</h3>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>✓ Real-time threat detection</li>
              <li>✓ Cross-reference with fraud database</li>
              <li>✓ Instant risk assessment</li>
              <li>✓ Transaction verification</li>
            </ul>
          </div>

          <div className="p-4 rounded-lg bg-emerald-950/40 border border-emerald-900/30 space-y-2">
            <h3 className="font-semibold text-emerald-300 text-sm">Generate Benefits</h3>
            <ul className="text-sm text-gray-300 space-y-1">
              <li>✓ Secure payment links</li>
              <li>✓ Customer-friendly sharing</li>
              <li>✓ Trackable transactions</li>
              <li>✓ Downloadable codes</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
