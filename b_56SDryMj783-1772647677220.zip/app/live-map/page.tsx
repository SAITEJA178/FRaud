'use client';

import { useState, useEffect } from 'react';
import { Activity, AlertTriangle } from 'lucide-react';

interface FraudIncident {
  id: string;
  lat: number;
  lng: number;
  city: string;
  sector: string;
  amount: number;
  timestamp: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
}

interface SectorData {
  sector: string;
  amount: number;
  cardNumber: string;
  ip: string;
}

export default function LiveMapPage() {
  const [fraudIncidents, setFraudIncidents] = useState<FraudIncident[]>([
    { id: '1', lat: 28.6139, lng: 77.209, city: 'New Delhi', sector: 'Delhi Sector', amount: 145000, timestamp: '2:34 PM', severity: 'critical' },
    { id: '2', lat: 19.0760, lng: 72.8777, city: 'Mumbai', sector: 'Mumbai Sector', amount: 98500, timestamp: '2:28 PM', severity: 'high' },
    { id: '3', lat: 13.0827, lng: 80.2707, city: 'Chennai', sector: 'Tamil Nadu Sector', amount: 52300, timestamp: '2:15 PM', severity: 'medium' },
    { id: '4', lat: 17.3850, lng: 78.4867, city: 'Hyderabad', sector: 'Hyderabad Sector', amount: 145758, timestamp: '2:45 PM', severity: 'critical' },
    { id: '5', lat: 15.2993, lng: 75.7597, city: 'Bangalore', sector: 'Karnataka Sector', amount: 67200, timestamp: '2:20 PM', severity: 'high' },
    { id: '6', lat: 22.5726, lng: 88.3639, city: 'Kolkata', sector: 'West Bengal Sector', amount: 34890, timestamp: '2:10 PM', severity: 'medium' },
  ]);

  const [sectorStats, setSectorStats] = useState<SectorData[]>([
    { sector: 'Hyderabad Sector', amount: 145758, cardNumber: '•••• •••• •••• 7681', ip: '183.136.175.136' },
    { sector: 'Delhi Sector', amount: 128432, cardNumber: '•••• •••• •••• 9867', ip: '183.136.175.136' },
    { sector: 'Mumbai Sector', amount: 132413, cardNumber: '•••• •••• •••• 4043', ip: '183.193.184.86' },
  ]);

  const [totalScans, setTotalScans] = useState(1248);
  const [totalThreats, setTotalThreats] = useState(383);

  useEffect(() => {
    const scanInterval = setInterval(() => {
      setTotalScans((prev) => prev + Math.floor(Math.random() * 5) + 1);
      setTotalThreats((prev) => prev + Math.floor(Math.random() * 3));
    }, 3000);

    return () => clearInterval(scanInterval);
  }, []);

  // Map coordinates for fraud incidents (normalized to 0-100 scale based on India bounds)
  const getMapPosition = (lat: number, lng: number) => {
    // India bounds: lat 8.4 to 35.5, lng 68.7 to 97.25
    const x = ((lng - 68.7) / (97.25 - 68.7)) * 100;
    const y = ((35.5 - lat) / (35.5 - 8.4)) * 100;
    return { x, y };
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-500';
      case 'high':
        return 'bg-orange-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'low':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      {/* Header */}
      <div className="bg-slate-900/50 border-b border-slate-800 px-6 py-4">
        <h1 className="text-2xl font-bold">PAYMENT THREAT AI</h1>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar */}
        <div className="w-80 bg-slate-900 border-r border-slate-800 p-6 overflow-y-auto">
          <div className="mb-2">
            <p className="text-cyan-400 text-xs font-semibold tracking-wider flex items-center gap-2">
              <Activity className="w-3 h-3" /> LIVE NEURAL STREAM
            </p>
          </div>
          <h2 className="text-4xl font-bold mb-8">Fraud Command</h2>

          {/* Total Scans */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 mb-4">
            <p className="text-slate-400 text-sm font-semibold mb-2">TOTAL SCANS</p>
            <p className="text-4xl font-bold text-white">{totalScans}</p>
          </div>

          {/* Threats */}
          <div className="bg-red-950/30 border border-red-900/50 rounded-lg p-6 mb-4">
            <p className="text-red-400 text-sm font-semibold mb-2">THREATS</p>
            <p className="text-4xl font-bold text-red-500">{totalThreats}</p>
          </div>

          {/* Real-time Intercepts */}
          <div>
            <p className="text-slate-400 text-sm font-semibold mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" /> REAL-TIME INTERCEPTS
              <span className="text-cyan-400 ml-auto">ACTIVE_GRID</span>
            </p>
            {sectorStats.map((sector, idx) => (
              <div key={idx} className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 mb-3">
                <p className="font-semibold text-white">{sector.sector}</p>
                <p className="text-red-400 font-bold text-lg mt-1">₹{(sector.amount / 1000).toFixed(1)}K</p>
                <p className="text-xs text-slate-400 mt-2">CARD: {sector.cardNumber}</p>
                <p className="text-xs text-slate-400">IP: {sector.ip}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Main Map Area */}
        <div className="flex-1 bg-blue-50 relative overflow-hidden">
          {/* Accuracy Badge */}
          <div className="absolute top-6 right-6 bg-slate-700/80 text-center rounded-lg px-6 py-4 z-10">
            <p className="text-slate-400 text-sm font-semibold">DETECTION ACCURACY</p>
            <p className="text-cyan-400 text-3xl font-bold">99.8%</p>
          </div>

          {/* SVG Map Container */}
          <svg
            className="w-full h-full"
            viewBox="0 0 100 100"
            preserveAspectRatio="xMidYMid slice"
          >
            {/* India Map Background - Light gradient */}
            <defs>
              <linearGradient id="mapGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style={{ stopColor: '#e0f2fe', stopOpacity: 1 }} />
                <stop offset="100%" style={{ stopColor: '#bae6fd', stopOpacity: 1 }} />
              </linearGradient>
              <pattern id="waterPattern" x="0" y="0" width="4" height="4" patternUnits="userSpaceOnUse">
                <rect width="4" height="4" fill="#87ceeb" />
                <circle cx="2" cy="2" r="1.5" fill="#5ba3d0" opacity="0.3" />
              </pattern>
            </defs>

            {/* Base map */}
            <rect width="100" height="100" fill="url(#mapGradient)" />

            {/* Simplified India outline (rough approximation) */}
            <path
              d="M 20 35 L 25 32 L 28 30 L 32 28 L 35 28 L 38 30 L 40 28 L 43 30 L 45 28 L 48 30 L 50 28 L 52 32 L 55 30 L 58 32 L 60 35 L 62 33 L 65 35 L 67 38 L 65 42 L 68 45 L 70 48 L 68 50 L 70 52 L 72 55 L 70 58 L 68 60 L 65 58 L 62 60 L 60 58 L 58 60 L 55 58 L 52 60 L 50 62 L 48 64 L 45 62 L 42 64 L 40 62 L 38 64 L 35 62 L 32 64 L 30 62 L 28 64 L 25 62 L 22 60 L 20 58 L 18 55 L 15 52 L 12 50 L 10 45 L 12 42 L 15 40 L 18 38 L 20 35 Z"
              fill="#e8f4f8"
              stroke="#94a3b8"
              strokeWidth="0.5"
            />

            {/* Fraud Incident Markers */}
            {fraudIncidents.map((incident) => {
              const pos = getMapPosition(incident.lat, incident.lng);
              const color = incident.severity === 'critical' ? '#ef4444' : incident.severity === 'high' ? '#f97316' : incident.severity === 'medium' ? '#eab308' : '#22c55e';

              return (
                <g key={incident.id}>
                  {/* Pulsing ring for critical incidents */}
                  {incident.severity === 'critical' && (
                    <>
                      <circle cx={pos.x} cy={pos.y} r="2.5" fill={color} opacity="0.3">
                        <animate attributeName="r" from="2.5" to="4" dur="1.5s" repeatCount="indefinite" />
                        <animate attributeName="opacity" from="0.3" to="0" dur="1.5s" repeatCount="indefinite" />
                      </circle>
                    </>
                  )}
                  {/* Main marker */}
                  <circle cx={pos.x} cy={pos.y} r="1.2" fill={color} stroke="white" strokeWidth="0.2" />
                  {/* City label */}
                  <text x={pos.x + 1.5} y={pos.y - 0.8} fontSize="0.8" fill="#1f2937" fontWeight="500">
                    {incident.city}
                  </text>
                </g>
              );
            })}
          </svg>

          {/* Yellow India Banner */}
          <div className="absolute bottom-0 left-0 right-0 bg-yellow-400 h-16 flex items-center justify-between px-8">
            <div className="flex items-center gap-4">
              <div className="w-10 h-8 bg-orange-500 border-2 border-white rounded flex items-center justify-center">
                <span className="text-white text-xs font-bold">IN</span>
              </div>
            </div>
            <span className="text-4xl font-black text-gray-800">INDIA</span>
          </div>
        </div>
      </div>
    </div>
  );
}
