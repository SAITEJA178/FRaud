'use client';

import { useState } from 'react';
import { FileText, Upload, Download, Check, AlertTriangle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface BatchResult {
  id: string;
  input: string;
  status: 'safe' | 'threat' | 'processing';
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  timestamp: string;
}

export default function BatchPage() {
  const [batchText, setBatchText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<BatchResult[]>([]);
  const [uploadedFileName, setUploadedFileName] = useState('');

  const processBatch = async () => {
    if (!batchText.trim()) return;

    setIsProcessing(true);
    try {
      const lines = batchText.split('\n').filter((line) => line.trim());

      // Simulate processing
      await new Promise((resolve) => setTimeout(resolve, 1500));

      const newResults: BatchResult[] = lines.map((line, idx) => ({
        id: `batch-${idx + 1}`,
        input: line.trim(),
        status: Math.random() > 0.7 ? 'threat' : 'safe',
        riskLevel: ['low', 'medium', 'high', 'critical'][
          Math.floor(Math.random() * 4)
        ] as any,
        timestamp: new Date().toLocaleTimeString(),
      }));

      setResults(newResults);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFileName(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        setBatchText(content);
      };
      reader.readAsText(file);
    }
  };

  const downloadResults = () => {
    const csv = results
      .map(
        (r) =>
          `"${r.input}","${r.status}","${r.riskLevel}","${r.timestamp}"`
      )
      .join('\n');

    const header = '"Input","Status","Risk Level","Timestamp"\n';
    const blob = new Blob([header + csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `batch-results-${Date.now()}.csv`;
    link.click();
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'critical':
        return 'bg-red-900/50 text-red-200 border-red-700/50';
      case 'high':
        return 'bg-orange-900/50 text-orange-200 border-orange-700/50';
      case 'medium':
        return 'bg-yellow-900/50 text-yellow-200 border-yellow-700/50';
      case 'low':
        return 'bg-emerald-900/50 text-emerald-200 border-emerald-700/50';
      default:
        return 'bg-slate-900/50 text-slate-200 border-slate-700/50';
    }
  };

  const stats = {
    total: results.length,
    safe: results.filter((r) => r.status === 'safe').length,
    threats: results.filter((r) => r.status === 'threat').length,
    processed: results.filter((r) => r.status !== 'processing').length,
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        {/* Page Header */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <FileText className="w-6 h-6 text-cyan-400" />
            <h1 className="text-3xl font-bold">Batch Processing</h1>
          </div>
          <p className="text-gray-400">Analyze multiple payment IDs, URLs, or contacts at once</p>
        </div>

        {/* Input Section */}
        <div className="space-y-4">
          <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50 space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">
                Paste or Upload Data
              </label>
              <p className="text-xs text-gray-500">
                Enter one UPI ID, phone, email, or URL per line
              </p>
            </div>

            <textarea
              value={batchText}
              onChange={(e) => setBatchText(e.target.value)}
              placeholder="rajesh@upi&#10;+91 98765 43210&#10;merchant@example.com&#10;https://payment.example.com"
              className="w-full h-32 px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-gray-600 font-mono text-sm focus:outline-none focus:border-cyan-500 resize-none"
            />

            <div className="flex gap-3">
              <Button
                onClick={processBatch}
                disabled={isProcessing || !batchText.trim()}
                className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Process Batch'
                )}
              </Button>

              <label className="flex-1">
                <input
                  type="file"
                  accept=".txt,.csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <div className="h-10 flex items-center justify-center px-4 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded-lg cursor-pointer transition-colors">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload File
                </div>
              </label>
            </div>

            {uploadedFileName && (
              <p className="text-xs text-cyan-400">Loaded: {uploadedFileName}</p>
            )}
          </div>
        </div>

        {/* Stats */}
        {results.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 rounded-lg bg-slate-900/50 border border-slate-700/30">
              <p className="text-xs text-gray-400 mb-1">TOTAL PROCESSED</p>
              <p className="text-2xl font-bold">{stats.processed}</p>
            </div>
            <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-900/30">
              <p className="text-xs text-emerald-300 mb-1">SAFE</p>
              <p className="text-2xl font-bold text-emerald-200">{stats.safe}</p>
            </div>
            <div className="p-3 rounded-lg bg-red-950/40 border border-red-900/30">
              <p className="text-xs text-red-300 mb-1">THREATS</p>
              <p className="text-2xl font-bold text-red-200">{stats.threats}</p>
            </div>
            <div className="p-3 rounded-lg bg-slate-900/50 border border-slate-700/30">
              <p className="text-xs text-gray-400 mb-1">THREAT RATE</p>
              <p className="text-2xl font-bold text-orange-400">
                {stats.total > 0
                  ? ((stats.threats / stats.total) * 100).toFixed(0)
                  : 0}
                %
              </p>
            </div>
          </div>
        )}

        {/* Results */}
        {results.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-gray-300">Results ({results.length})</h3>
              <Button
                onClick={downloadResults}
                variant="outline"
                size="sm"
                className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
              >
                <Download className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {results.map((result) => (
                <div
                  key={result.id}
                  className={`p-3 rounded-lg border ${getRiskColor(result.riskLevel)} flex items-center justify-between gap-3`}
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    {result.status === 'threat' ? (
                      <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                    ) : result.status === 'processing' ? (
                      <Loader2 className="w-4 h-4 animate-spin flex-shrink-0" />
                    ) : (
                      <Check className="w-4 h-4 flex-shrink-0" />
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-mono truncate">{result.input}</p>
                      <p className="text-xs opacity-75">{result.timestamp}</p>
                    </div>
                  </div>
                  <Badge className="flex-shrink-0 text-xs">
                    {result.riskLevel.toUpperCase()}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-6 border-t border-slate-700/50">
          <div className="p-4 rounded-lg bg-cyan-950/20 border border-cyan-900/30 space-y-2">
            <h4 className="font-semibold text-cyan-300 text-sm">Format Support</h4>
            <ul className="text-xs text-gray-400 space-y-1">
              <li>• One entry per line</li>
              <li>• UPI IDs (user@bank)</li>
              <li>• Phone numbers (+91...)</li>
              <li>• Emails & URLs</li>
            </ul>
          </div>

          <div className="p-4 rounded-lg bg-emerald-950/20 border border-emerald-900/30 space-y-2">
            <h4 className="font-semibold text-emerald-300 text-sm">Processing Features</h4>
            <ul className="text-xs text-gray-400 space-y-1">
              <li>• Real-time threat detection</li>
              <li>• Bulk analysis (up to 1000 items)</li>
              <li>• CSV export results</li>
              <li>• Risk scoring</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
