'use client';

import { useState, useEffect } from 'react';
import { AlertTriangle, Zap, Loader2 } from 'lucide-react';
import { ThreatSearch } from '@/components/threat-search';
import { ThreatList } from '@/components/threat-list';
import { generateMockThreats, Threat } from '@/lib/mock-data';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export default function SpamIntelPage() {
  const [threats, setThreats] = useState<Threat[]>(generateMockThreats(8));
  const [isLoading, setIsLoading] = useState(false);
  const [detectedThreats, setDetectedThreats] = useState<Threat[]>([]);
  const [threatStats, setThreatStats] = useState({
    critical: 2,
    high: 5,
    medium: 8,
    low: 15,
  });

  const handleDetectThreat = async (query: string) => {
    setIsLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));

      const newThreats = generateMockThreats(3);
      setDetectedThreats(newThreats);

      // Update stats
      setThreatStats((prev) => ({
        ...prev,
        critical: prev.critical + (Math.random() > 0.7 ? 1 : 0),
        high: prev.high + (Math.random() > 0.6 ? 1 : 0),
      }));
    } finally {
      setIsLoading(false);
    }
  };

  const clearLogs = () => {
    setDetectedThreats([]);
  };

  const threatDistribution = [
    { label: 'Critical', count: threatStats.critical, color: 'bg-red-500' },
    { label: 'High', count: threatStats.high, color: 'bg-orange-500' },
    { label: 'Medium', count: threatStats.medium, color: 'bg-yellow-500' },
    { label: 'Low', count: threatStats.low, color: 'bg-emerald-500' },
  ];

  const totalThreats = Object.values(threatStats).reduce((a, b) => a + b, 0);

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-6xl mx-auto px-6 py-8 space-y-8">
        {/* Page Header */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-red-400" />
            <h1 className="text-3xl font-bold">Spam Intel Node</h1>
          </div>
          <p className="text-gray-400">Live identity blacklist and spam detection</p>
        </div>

        {/* Detection Section */}
        <div className="space-y-4">
          <ThreatSearch
            placeholder="Enter Phone, ID or Email..."
            onSearch={handleDetectThreat}
            isLoading={isLoading}
            buttonText="DETECT THREAT"
          />
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="p-4 rounded-lg bg-red-950/40 border border-red-900/30">
            <p className="text-xs text-red-300 font-medium mb-1">CRITICAL</p>
            <p className="text-2xl font-bold text-red-200">{threatStats.critical}</p>
          </div>
          <div className="p-4 rounded-lg bg-orange-950/40 border border-orange-900/30">
            <p className="text-xs text-orange-300 font-medium mb-1">HIGH</p>
            <p className="text-2xl font-bold text-orange-200">{threatStats.high}</p>
          </div>
          <div className="p-4 rounded-lg bg-yellow-950/40 border border-yellow-900/30">
            <p className="text-xs text-yellow-300 font-medium mb-1">MEDIUM</p>
            <p className="text-2xl font-bold text-yellow-200">{threatStats.medium}</p>
          </div>
          <div className="p-4 rounded-lg bg-slate-900/40 border border-slate-700/30">
            <p className="text-xs text-gray-300 font-medium mb-1">LOW</p>
            <p className="text-2xl font-bold text-gray-200">{threatStats.low}</p>
          </div>
        </div>

        {/* Threat Distribution */}
        <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50 space-y-4">
          <h3 className="text-sm font-semibold text-gray-300">Threat Distribution</h3>

          <div className="space-y-3">
            {threatDistribution.map((item) => {
              const percentage = totalThreats > 0 ? (item.count / totalThreats) * 100 : 0;
              return (
                <div key={item.label} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">{item.label}</span>
                    <span className="font-bold text-white">{item.count}</span>
                  </div>
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${item.color} transition-all duration-300`}
                      style={{ width: `${percentage}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-3 border-t border-slate-700/30">
            <p className="text-xs text-gray-500">Total Active Threats: {totalThreats}</p>
          </div>
        </div>

        {/* Main Blacklist */}
        <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50">
          <ThreatList threats={threats} showActions={true} />
        </div>

        {/* Detected Threats */}
        {detectedThreats.length > 0 && (
          <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50 space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-gray-300 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                SCAN RESULTS
              </h3>
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-500 hover:text-red-400 text-xs"
                onClick={clearLogs}
              >
                Clear Results
              </Button>
            </div>

            <ThreatList threats={detectedThreats} showActions={false} />
          </div>
        )}

        {/* Information Panel */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-lg bg-red-950/20 border border-red-900/30 space-y-2">
            <h4 className="font-semibold text-red-300 text-sm">How It Works</h4>
            <p className="text-xs text-gray-400">
              Our real-time spam detection system monitors millions of phone numbers, emails, and
              UPI IDs. Each entry is verified against known fraud patterns and user reports.
            </p>
          </div>

          <div className="p-4 rounded-lg bg-cyan-950/20 border border-cyan-900/30 space-y-2">
            <h4 className="font-semibold text-cyan-300 text-sm">Report a Threat</h4>
            <p className="text-xs text-gray-400">
              If you encounter a suspicious contact or transaction, report it immediately. Your
              reports help protect the entire community.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
