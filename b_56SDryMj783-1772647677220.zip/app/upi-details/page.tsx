'use client';

import { useState } from 'react';
import { Search, Zap, AlertTriangle, CheckCircle, XCircle, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface UPIData {
  name: string;
  phoneNumber: string;
  upiId: string;
  bankName: string;
  accountType: string;
  email: string;
  aadharVerified: boolean;
  aadharLast4: string;
  age: number;
  gender: string;
  location: string;
  sector: string;
  monthlyIncome: string;
  employmentType: string;
  accountAgeYears: number;
  maritalStatus: string;
  totalTransactions: number;
  reportedCases: number;
  fraudRisk: string;
  trustScore: string;
  trustPercentage: number;
  lastTransaction: string;
  bankBalance?: string;
  creditScore?: string;
}

export default function UPIDetailsPage() {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [upiId, setUpiId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [upiData, setUpiData] = useState<UPIData | null>(null);
  const [errorMessage, setErrorMessage] = useState('');

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'critical':
        return 'bg-red-900/20 border-red-700 text-red-400';
      case 'high':
        return 'bg-orange-900/20 border-orange-700 text-orange-400';
      case 'medium':
        return 'bg-yellow-900/20 border-yellow-700 text-yellow-400';
      case 'low':
        return 'bg-green-900/20 border-green-700 text-green-400';
      default:
        return 'bg-slate-800/20 border-slate-700 text-slate-400';
    }
  };

  const getTrustColor = (score: string) => {
    switch (score) {
      case 'verified':
        return 'bg-green-900/30 border-green-700/50 text-green-300';
      case 'high':
        return 'bg-cyan-900/30 border-cyan-700/50 text-cyan-300';
      case 'medium':
        return 'bg-yellow-900/30 border-yellow-700/50 text-yellow-300';
      case 'low':
        return 'bg-orange-900/30 border-orange-700/50 text-orange-300';
      case 'suspicious':
        return 'bg-red-900/30 border-red-700/50 text-red-300';
      default:
        return 'bg-slate-800/30 border-slate-700/50 text-slate-400';
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber.trim() || !upiId.trim()) return;

    setIsLoading(true);
    setErrorMessage('');

    try {
      const response = await fetch('/api/upi-lookup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber, upiId })
      });

      const result = await response.json();

      if (response.ok && result.success && result.data) {
        setUpiData(result.data);
      } else {
        setErrorMessage(result.message || 'User not found in database');
        setUpiData(null);
      }
    } catch (error) {
      console.error('Search error:', error);
      setErrorMessage('Connection error. Please try again.');
      setUpiData(null);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">UPI & Phone Fraud Detection</h1>
          <p className="text-cyan-400 text-lg">Verify identity & detect fraudulent accounts</p>
        </div>

        {/* Test Data Info */}
        <div className="bg-blue-950/40 border border-blue-900/50 rounded-lg p-4 mb-6">
          <div className="flex gap-2">
            <Zap className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-blue-200">
              <strong>Test with:</strong> Phone <code className="bg-slate-800 px-2 py-0.5 rounded text-xs text-cyan-300">9515543319</code> + UPI <code className="bg-slate-800 px-2 py-0.5 rounded text-xs text-cyan-300">9515543319@ybl</code>
            </div>
          </div>
        </div>

        {/* Search Form */}
        <div className="bg-slate-900/50 border border-cyan-500/20 rounded-lg p-6 mb-8">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-cyan-300 text-sm font-semibold mb-2">Phone Number</label>
                <input
                  type="tel"
                  placeholder="9515543319"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="block text-cyan-300 text-sm font-semibold mb-2">UPI ID</label>
                <input
                  type="text"
                  placeholder="9515543319@ybl"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={isLoading || !phoneNumber.trim() || !upiId.trim()}
              className="w-full bg-cyan-500 hover:bg-cyan-600 text-black font-bold py-3 rounded-lg disabled:opacity-50"
            >
              <Search className="w-4 h-4 mr-2" />
              {isLoading ? 'Analyzing...' : 'Search & Verify'}
            </Button>

            {errorMessage && (
              <div className="bg-red-900/30 border border-red-700 rounded-lg p-4 text-red-300">
                {errorMessage}
              </div>
            )}
          </form>
        </div>

        {/* Results */}
        {upiData && (
          <div className="space-y-6">
            {/* Header Card */}
            <div className="bg-gradient-to-r from-cyan-900/40 to-slate-900/40 border border-cyan-500/20 rounded-lg p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h2 className="text-3xl font-bold text-white mb-2">{upiData.name}</h2>
                  <p className="text-cyan-400 text-lg">{upiData.bankName}</p>
                </div>
                <div className="text-right">
                  <div className={`inline-block px-4 py-2 rounded-lg border ${getTrustColor(upiData.trustScore)}`}>
                    <div className="font-bold text-lg">{upiData.trustPercentage}%</div>
                    <div className="text-xs font-semibold uppercase">{upiData.trustScore}</div>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-slate-400">Phone:</span>
                  <p className="text-white font-semibold">+91 {upiData.phoneNumber}</p>
                </div>
                <div>
                  <span className="text-slate-400">UPI ID:</span>
                  <p className="text-white font-semibold">{upiData.upiId}</p>
                </div>
                <div>
                  <span className="text-slate-400">Email:</span>
                  <p className="text-white font-semibold">{upiData.email}</p>
                </div>
              </div>
            </div>

            {/* Two Column Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Personal Details */}
              <div className="lg:col-span-2 space-y-6">
                {/* Personal Info */}
                <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Personal Details</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-400">Age</span>
                      <p className="text-white font-semibold">{upiData.age} years old</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Gender</span>
                      <p className="text-white font-semibold">{upiData.gender}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Location</span>
                      <p className="text-white font-semibold">{upiData.location}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Marital Status</span>
                      <p className="text-white font-semibold">{upiData.maritalStatus}</p>
                    </div>
                  </div>
                </div>

                {/* Financial Details */}
                <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Financial Details</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-400">Monthly Income</span>
                      <p className="text-white font-semibold">{upiData.monthlyIncome}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Employment</span>
                      <p className="text-white font-semibold">{upiData.employmentType}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Account Age</span>
                      <p className="text-white font-semibold">{upiData.accountAgeYears} years</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Total Transactions</span>
                      <p className="text-white font-semibold">{upiData.totalTransactions}</p>
                    </div>
                  </div>
                </div>



                {/* Account Info */}
                <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6">
                  <h3 className="text-xl font-bold text-white mb-4">Account Information</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-400">Account Type</span>
                      <p className="text-white font-semibold">{upiData.accountType}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Sector</span>
                      <p className="text-white font-semibold">{upiData.sector}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Last Transaction</span>
                      <p className="text-white font-semibold">{new Date(upiData.lastTransaction).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Reported Cases</span>
                      <p className="text-white font-semibold">{upiData.reportedCases}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column - Verification & Risk */}
              <div className="space-y-6">
                {/* Aadhar Verification */}
                <div className={`border rounded-lg p-6 ${upiData.aadharVerified ? 'bg-green-900/20 border-green-700/50' : 'bg-red-900/20 border-red-700/50'}`}>
                  <div className="flex items-center gap-3 mb-3">
                    {upiData.aadharVerified ? (
                      <CheckCircle className="w-6 h-6 text-green-400" />
                    ) : (
                      <XCircle className="w-6 h-6 text-red-400" />
                    )}
                    <h3 className="text-lg font-bold text-white">Aadhar Verification</h3>
                  </div>
                  <div className={upiData.aadharVerified ? 'text-green-300' : 'text-red-300'}>
                    {upiData.aadharVerified ? (
                      <>
                        <p className="font-semibold mb-2">Verified</p>
                        <p className="text-sm">Aadhar Last 4: {upiData.aadharLast4}</p>
                      </>
                    ) : (
                      <p className="font-semibold">Not Verified</p>
                    )}
                  </div>
                </div>

                {/* Trust Score Batch */}
                <div className={`border rounded-lg p-6 ${getTrustColor(upiData.trustScore)}`}>
                  <div className="flex items-center gap-3 mb-3">
                    <AlertTriangle className="w-6 h-6" />
                    <h3 className="text-lg font-bold">Trust Score Batch</h3>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <div className="text-2xl font-bold">{upiData.trustPercentage}%</div>
                      <div className="text-sm opacity-90">{upiData.trustScore.toUpperCase()}</div>
                    </div>
                    <div className="w-full bg-slate-800/50 rounded-full h-2">
                      <div
                        className={`h-full rounded-full ${
                          upiData.trustScore === 'verified'
                            ? 'bg-green-500'
                            : upiData.trustScore === 'high'
                            ? 'bg-cyan-500'
                            : upiData.trustScore === 'medium'
                            ? 'bg-yellow-500'
                            : upiData.trustScore === 'low'
                            ? 'bg-orange-500'
                            : 'bg-red-500'
                        }`}
                        style={{ width: `${upiData.trustPercentage}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Fraud Risk */}
                <div className={`border rounded-lg p-6 ${getRiskColor(upiData.fraudRisk)}`}>
                  <h3 className="text-lg font-bold mb-3">Fraud Risk Level</h3>
                  <div className="text-2xl font-bold uppercase">{upiData.fraudRisk}</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {!upiData && !isLoading && !errorMessage && (
          <div className="bg-slate-900/30 border border-slate-800 rounded-lg p-12 text-center">
            <MapPin className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <p className="text-slate-400">Enter phone number and UPI ID to lookup user details</p>
          </div>
        )}
      </div>
    </div>
  );
}
