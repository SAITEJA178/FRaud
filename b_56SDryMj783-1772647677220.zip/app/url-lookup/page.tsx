'use client';

import { useState } from 'react';
import { Search, TrendingUp, Clock, Shield, AlertTriangle } from 'lucide-react';
import { ThreatSearch } from '@/components/threat-search';
import { ThreatList } from '@/components/threat-list';
import { generateMockThreats, generateSecurityScore } from '@/lib/mock-data';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export default function URLLookupPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [threats, setThreats] = useState(generateMockThreats(0));
  const [isLoading, setIsLoading] = useState(false);
  const [lookupResult, setLookupResult] = useState<any>(null);
  const securityScore = generateSecurityScore();

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 800));

      const newThreats = generateMockThreats(5);
      setThreats(newThreats);

      const riskDetected = Math.random() > 0.5;
      const severity = riskDetected
        ? ['critical', 'high', 'medium', 'low'][Math.floor(Math.random() * 4)]
        : 'low';

      setLookupResult({
        query: query,
        riskDetected,
        severity,
        matchedThreats: newThreats.length,
        lastUpdated: new Date(),
        riskPercentage: riskDetected ? Math.floor(Math.random() * 100) + 20 : Math.floor(Math.random() * 20),
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getRiskColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-950/40 border-red-900/30 text-red-100';
      case 'high':
        return 'bg-orange-950/40 border-orange-900/30 text-orange-100';
      case 'medium':
        return 'bg-yellow-950/40 border-yellow-900/30 text-yellow-100';
      default:
        return 'bg-emerald-950/40 border-emerald-900/30 text-emerald-100';
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-6xl mx-auto px-6 py-8 space-y-8">
        {/* Page Header */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Search className="w-6 h-6 text-cyan-400" />
            <h1 className="text-3xl font-bold">URL & UPI Lookup</h1>
          </div>
          <p className="text-gray-400">Deep identity and transaction intelligence</p>
        </div>

        {/* Search Section */}
        <div className="space-y-4">
          <ThreatSearch
            placeholder="Enter UPI ID or Payment URL (e.g. rajesh@upi)..."
            onSearch={handleSearch}
            isLoading={isLoading}
            buttonText="LOOKUP"
          />
        </div>

        {/* Results Section */}
        {lookupResult && (
          <div className="space-y-6">
            {/* Risk Assessment Card */}
            <div className={`p-6 rounded-lg border ${getRiskColor(lookupResult.severity)} space-y-4`}>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold text-lg mb-1">
                    {lookupResult.riskDetected ? 'Risk Detected' : 'Safe to Proceed'}
                  </h3>
                  <p className="text-sm opacity-90">for: {searchQuery}</p>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold">{lookupResult.riskPercentage}%</div>
                  <p className="text-xs opacity-75">Risk Score</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 pt-3 border-t border-current/20">
                <div>
                  <p className="text-xs opacity-75">Matched Threats</p>
                  <p className="text-lg font-bold">{lookupResult.matchedThreats}</p>
                </div>
                <div>
                  <p className="text-xs opacity-75">Last Updated</p>
                  <p className="text-xs font-mono">
                    {lookupResult.lastUpdated.toLocaleTimeString()}
                  </p>
                </div>
                <div>
                  <p className="text-xs opacity-75">Severity</p>
                  <Badge className="mt-1 text-xs">
                    {lookupResult.severity.toUpperCase()}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Details Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-700/50 space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <TrendingUp className="w-4 h-4" />
                  <span>Threat Level</span>
                </div>
                <p className="text-xl font-bold text-red-400">
                  {lookupResult.riskDetected ? 'HIGH' : 'LOW'}
                </p>
              </div>

              <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-700/50 space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Clock className="w-4 h-4" />
                  <span>Last Seen</span>
                </div>
                <p className="text-lg font-bold text-gray-300">2 mins ago</p>
              </div>

              <div className="p-4 rounded-lg bg-slate-900/50 border border-slate-700/50 space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Shield className="w-4 h-4" />
                  <span>Trust Score</span>
                </div>
                <p className="text-lg font-bold text-cyan-400">{100 - lookupResult.riskPercentage}%</p>
              </div>
            </div>

            {/* Threat List */}
            <div className="p-6 rounded-lg bg-slate-900/50 border border-slate-700/50">
              <ThreatList threats={threats} showActions={false} />
            </div>
          </div>
        )}

        {/* Empty State */}
        {!lookupResult && (
          <div className="text-center py-12 space-y-4">
            <Search className="w-16 h-16 mx-auto text-gray-700" />
            <div>
              <h3 className="text-lg font-semibold text-gray-400 mb-2">No Lookup Performed</h3>
              <p className="text-gray-500">Enter a UPI ID or payment URL to check for threats</p>
            </div>
          </div>
        )}

        {/* Related Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-6 border-t border-slate-700/50">
          <div className="p-4 rounded-lg bg-cyan-950/20 border border-cyan-900/30 space-y-2">
            <h4 className="font-semibold text-cyan-300 text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              UPI ID Information
            </h4>
            <p className="text-xs text-gray-400">
              UPI IDs are validated against our database of known merchant identities and fraud patterns.
              Always verify the merchant before making payments.
            </p>
          </div>

          <div className="p-4 rounded-lg bg-emerald-950/20 border border-emerald-900/30 space-y-2">
            <h4 className="font-semibold text-emerald-300 text-sm flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Payment URL Safety
            </h4>
            <p className="text-xs text-gray-400">
              Payment URLs are analyzed for SSL certificates, domain legitimacy, and suspicious patterns
              that may indicate phishing or fraud attempts.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
