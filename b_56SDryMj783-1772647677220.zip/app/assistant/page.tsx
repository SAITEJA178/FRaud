'use client';

import { useState, useEffect } from 'react';
import { Wand2, Send, Loader2, AlertTriangle, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: string;
  threatInfo?: {
    found: boolean;
    riskLevel: string;
    details: string;
  };
}

export default function AssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'intro',
      type: 'assistant',
      content:
        "Hello! I'm your Payment Threat Intelligence Assistant. I can help you analyze payment IDs, URLs, phone numbers, and emails for potential fraud risks. Ask me anything like 'Is rajesh@upi safe?' or 'Check this payment link for fraud'.",
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: `msg-${Date.now()}`,
      type: 'user',
      content: input,
      timestamp: new Date().toLocaleTimeString(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Simulate API response
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const threatFound = Math.random() > 0.6;
    const riskLevel = ['critical', 'high', 'medium', 'low'][
      Math.floor(Math.random() * 4)
    ];

    const assistantResponse: Message = {
      id: `msg-${Date.now() + 1}`,
      type: 'assistant',
      content: threatFound
        ? `I found potential security concerns with "${input}". This appears to be a ${riskLevel}-risk entry. ${
            riskLevel === 'critical'
              ? 'I strongly recommend avoiding this contact.'
              : riskLevel === 'high'
                ? 'Please be cautious with this entry.'
                : 'Exercise normal security precautions.'
          }`
        : `I've analyzed "${input}" and found no immediate threats in our database. However, always exercise caution when sharing payment information and verify merchant details independently.`,
      timestamp: new Date().toLocaleTimeString(),
      threatInfo: {
        found: threatFound,
        riskLevel: riskLevel,
        details: threatFound
          ? `Matched against ${Math.floor(Math.random() * 500) + 1} known threat patterns`
          : 'No matches found in threat database',
      },
    };

    setMessages((prev) => [...prev, assistantResponse]);
    setIsLoading(false);
  };

  const suggestedQuestions = [
    'Is rajesh@upi safe?',
    'Check this payment URL for fraud',
    'Analyze +91 98765 43210',
    'Is merchant@example.com legitimate?',
  ];

  const handleSuggestedQuestion = (question: string) => {
    setInput(question);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="border-b border-slate-700/50 bg-slate-950">
          <div className="max-w-3xl mx-auto px-6 py-4">
            <div className="flex items-center gap-2 mb-2">
              <Wand2 className="w-6 h-6 text-cyan-400" />
              <h1 className="text-2xl font-bold">AI Assistant</h1>
            </div>
            <p className="text-sm text-gray-400">
              Ask me about payment security, fraud detection, and threat intelligence
            </p>
          </div>
        </div>

        {/* Messages Container */}
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto px-6 py-8 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xl space-y-2 ${
                    message.type === 'user'
                      ? 'bg-cyan-600/40 border border-cyan-500/50 text-white'
                      : 'bg-slate-900/50 border border-slate-700/50 text-gray-100'
                  } p-4 rounded-lg`}
                >
                  <p className="text-sm leading-relaxed">{message.content}</p>

                  {message.threatInfo && (
                    <div
                      className={`p-3 rounded-lg mt-3 border ${
                        message.threatInfo.found
                          ? 'bg-red-950/40 border-red-900/30'
                          : 'bg-emerald-950/40 border-emerald-900/30'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        {message.threatInfo.found ? (
                          <AlertTriangle className="w-4 h-4 mt-0.5 text-red-400 flex-shrink-0" />
                        ) : (
                          <Shield className="w-4 h-4 mt-0.5 text-emerald-400 flex-shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium mb-1">
                            {message.threatInfo.found
                              ? 'Threat Detected'
                              : 'No Threats Found'}
                          </p>
                          <p className="text-xs opacity-75">
                            {message.threatInfo.details}
                          </p>
                          {message.threatInfo.found && (
                            <Badge className="mt-2 text-xs bg-red-900/50 text-red-200 border-red-700/50">
                              {message.threatInfo.riskLevel.toUpperCase()}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  <p className="text-xs text-gray-500 mt-2">{message.timestamp}</p>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-slate-900/50 border border-slate-700/50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 text-gray-400">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="text-sm">Analyzing...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Input Section */}
        <div className="border-t border-slate-700/50 bg-slate-950">
          <div className="max-w-3xl mx-auto px-6 py-6 space-y-4">
            {/* Suggested Questions */}
            {messages.length === 1 && (
              <div className="space-y-2">
                <p className="text-xs text-gray-500">SUGGESTED QUESTIONS:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {suggestedQuestions.map((question, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSuggestedQuestion(question)}
                      className="p-2 rounded-lg bg-slate-900/50 border border-slate-700/50 text-sm text-left text-gray-300 hover:border-cyan-500/50 hover:text-cyan-400 transition-colors text-xs"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input Form */}
            <div className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Ask about payment security, fraud detection, or any payment ID..."
                disabled={isLoading}
                className="flex-1 px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/20 transition-colors disabled:opacity-50"
              />
              <Button
                onClick={handleSendMessage}
                disabled={isLoading || !input.trim()}
                className="bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold px-6"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>

            <p className="text-xs text-gray-600 text-center">
              This assistant uses AI to analyze payment security risks. Always verify
              information independently.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
