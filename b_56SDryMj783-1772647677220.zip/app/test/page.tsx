export default function TestPage() {
  return (
    <div className="p-8 text-white">
      <h1 className="text-2xl font-bold mb-4">Test Page</h1>
      <p className="mb-4">If you can see this, the basic app is working.</p>
      <p className="text-sm text-gray-400">Next step: Check the main dashboard at /</p>
    </div>
  );
}
